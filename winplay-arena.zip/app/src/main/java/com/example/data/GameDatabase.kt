package com.example.data

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "users")
data class UserEntity(
    @PrimaryKey val id: Int = 1,
    val name: String,
    val avatarIndex: Int,
    val coins: Double,
    val tickets: Int,
    val xp: Int,
    val level: Int,
    val lastSpinTimestamp: Long
) {
    fun toUserUiState() = UserUiState(
        name = name,
        avatarIndex = avatarIndex,
        coins = coins,
        tickets = tickets,
        xp = xp,
        level = level,
        lastSpinTimestamp = lastSpinTimestamp
    )
}

data class UserUiState(
    val name: String = "Pro Gamer",
    val avatarIndex: Int = 1,
    val coins: Double = 100.0,
    val tickets: Int = 5,
    val xp: Int = 0,
    val level: Int = 1,
    val lastSpinTimestamp: Long = 0L
)

@Entity(tableName = "matches")
data class GameMatchEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val gameName: String,
    val entryFee: Double,
    val score: Int,
    val prizeWon: Double,
    val status: String, // "WON", "LOST", "COMPLETED"
    val timestamp: Long
)

@Entity(tableName = "leaderboard")
data class LeaderboardEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val gameName: String,
    val playerName: String,
    val score: Int,
    val avatarIndex: Int,
    val isUser: Boolean,
    val rank: Int = 0
)

@Dao
interface GameDao {
    @Query("SELECT * FROM users WHERE id = 1 LIMIT 1")
    fun getUserFlow(): Flow<UserEntity?>

    @Query("SELECT * FROM users WHERE id = 1 LIMIT 1")
    suspend fun getUserSync(): UserEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUser(user: UserEntity)

    @Update
    suspend fun updateUser(user: UserEntity)

    @Query("SELECT * FROM matches ORDER BY timestamp DESC")
    fun getAllMatchesFlow(): Flow<List<GameMatchEntity>>

    @Insert
    suspend fun insertMatch(match: GameMatchEntity)

    @Query("SELECT * FROM leaderboard ORDER BY score DESC")
    fun getAllLeaderboardFlow(): Flow<List<LeaderboardEntity>>

    @Query("SELECT * FROM leaderboard WHERE gameName = :gameName ORDER BY score DESC LIMIT 10")
    fun getLeaderboardForGameFlow(gameName: String): Flow<List<LeaderboardEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLeaderboardItems(items: List<LeaderboardEntity>)

    @Query("DELETE FROM leaderboard WHERE gameName = :gameName")
    suspend fun deleteLeaderboardForGame(gameName: String)

    @Query("DELETE FROM leaderboard")
    suspend fun clearLeaderboard()
}

@Database(
    entities = [UserEntity::class, GameMatchEntity::class, LeaderboardEntity::class],
    version = 1,
    exportSchema = false
)
abstract class GameDatabase : RoomDatabase() {
    abstract fun gameDao(): GameDao

    companion object {
        @Volatile
        private var INSTANCE: GameDatabase? = null

        fun getDatabase(context: Context): GameDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    GameDatabase::class.java,
                    "winplay_database"
                )
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
