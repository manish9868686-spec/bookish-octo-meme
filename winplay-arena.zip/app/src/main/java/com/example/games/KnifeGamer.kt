package com.example.games

import android.os.SystemClock
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin
import com.example.ui.GameOutcomeOverlay


data class Knife(
    val initialAngle: Float, // Relative angle on the wheel when embedded (0..360)
)

data class ShotKnife(
    var yPos: Float, // Vertical position from bottom (0 = ready at bottom, 1 = hit center)
    var isFlying: Boolean = false
)

data class VisualParticle(
    val x: Float,
    val y: Float,
    val vx: Float,
    val vy: Float,
    val color: Color,
    val size: Float,
    var alpha: Float = 1.0f
)

@Composable
fun KnifeGameScreen(
    entryFee: Double,
    onGameOver: (score: Int, prizeWon: Double) -> Unit,
    onBack: () -> Unit
) {
    val scope = rememberCoroutineScope()
    
    // Game state states: "INTRO", "PLAYING", "GAMEOVER", "VICTORY"
    var gameState by remember { mutableStateOf("INTRO") }
    var score by remember { mutableIntStateOf(0) }
    var knivesToEmbed by remember { mutableIntStateOf(6) } // Target knives to pass level
    var knivesRemaining by remember { mutableIntStateOf(6) }
    var currentLevel by remember { mutableIntStateOf(1) }
    
    // Angle representing current rotation of core in degrees
    var coreRotationAngle by remember { mutableStateOf(0f) }
    var coreSpeed by remember { mutableStateOf(1.8f) } // degrees per frame
    var rotationDirection by remember { mutableStateOf(1f) } // 1f = CW, -1f = CCW

    // Knives embedded on core (their static, core-relative angles)
    val embeddedKnives = remember { mutableStateListOf<Knife>() }
    
    // Flying knife state
    var flyingKnifeY by remember { mutableStateOf(0.8f) } // 0.8f is resting bottom, 0.25f is target radius hit
    var isKnifeFlying by remember { mutableStateOf(false) }
    
    // Particle effects
    val particles = remember { mutableStateListOf<VisualParticle>() }

    // Screen dimensions helpers (normalized layout)
    val coreCenterY = 0.32f // normalized position of the spinning disk (y coordinate)
    
    // Speed fluctuation coroutine for higher levels
    LaunchedEffect(gameState, currentLevel) {
        if (gameState == "PLAYING") {
            while (true) {
                if (currentLevel > 1) {
                    // Oscillating speed
                    delay(1500)
                    rotationDirection = if (Math.random() > 0.5) 1f else -1f
                    coreSpeed = (1.5f + Math.random() * 2.5f).toFloat()
                } else {
                    delay(2000)
                    if (Math.random() > 0.70) {
                        rotationDirection = -rotationDirection
                    }
                }
            }
        }
    }

    // Main game loop (updating core rotation and particles)
    LaunchedEffect(gameState) {
        if (gameState == "PLAYING") {
            var lastTime = SystemClock.uptimeMillis()
            while (gameState == "PLAYING") {
                val now = SystemClock.uptimeMillis()
                val delta = (now - lastTime).coerceAtMost(30)
                lastTime = now

                // Update wheel rotation
                coreRotationAngle = (coreRotationAngle + (coreSpeed * rotationDirection)) % 360f
                if (coreRotationAngle < 0) coreRotationAngle += 360f

                // Update flying knife
                if (isKnifeFlying) {
                    flyingKnifeY -= 0.065f // Move up
                    if (flyingKnifeY <= 0.32f + 0.08f) { // Reached core boundary! Wait, central disk is around y=0.32f
                        isKnifeFlying = false
                        
                        // Check collision with embedded knives
                        // The flying knife hits at absolute bottom (offset = 90 deg clockwise / 270 deg / -90 deg depending on math, 
                        // let's define hit angle relative to core's current rotation!).
                        // A knife hitting from exactly bottom has world position angle: 90 degrees (pointing straight down).
                        // To find its local angle on the rotating core, we subtract the core's current rotation from 90 degrees.
                        val worldHitAngle = 90f 
                        var hitLocalAngle = (worldHitAngle - coreRotationAngle) % 360f
                        if (hitLocalAngle < 0) hitLocalAngle += 360f

                        // Check collision with any embedded knife
                        var collided = false
                        for (knife in embeddedKnives) {
                            val diff = Math.abs(knife.initialAngle - hitLocalAngle)
                            val minDiff = Math.min(diff, 360f - diff)
                            if (minDiff < 14.5f) { // 14.5 degrees collision width
                                collided = true
                                break
                            }
                        }

                        if (collided) {
                            // Hit another knife -> Game over
                            gameState = "GAMEOVER"
                            // Create explosion of particles!
                            repeat(20) {
                                particles.add(
                                    VisualParticle(
                                        x = 0.5f,
                                        y = 0.32f + 0.12f,
                                        vx = (-0.015f + Math.random() * 0.03f).toFloat(),
                                        vy = (-0.01f + Math.random() * 0.02f).toFloat(),
                                        color = Color(0xFFFF3B30),
                                        size = 12f + (Math.random() * 8f).toFloat()
                                    )
                                )
                            }
                        } else {
                            // Embedded successfully!
                            embeddedKnives.add(Knife(hitLocalAngle))
                            score += 15
                            knivesRemaining--
                            
                            // Emit hit sparks at the point of contact
                            repeat(8) {
                                particles.add(
                                    VisualParticle(
                                        x = 0.5f,
                                        y = 0.32f + 0.1f,
                                        vx = (-0.01f + Math.random() * 0.02f).toFloat(),
                                        vy = (0.005f + Math.random() * 0.02f).toFloat(),
                                        color = Color(0xFFFFD700),
                                        size = 6f + (Math.random() * 6).toFloat()
                                    )
                                )
                            }

                            if (knivesRemaining <= 0) {
                                // Level complete!
                                if (currentLevel >= 3) {
                                    gameState = "VICTORY"
                                } else {
                                    // Move to next level
                                    scope.launch {
                                        delay(500)
                                        currentLevel++
                                        knivesToEmbed = 6 + currentLevel
                                        knivesRemaining = knivesToEmbed
                                        embeddedKnives.clear()
                                        coreSpeed += 0.8f
                                    }
                                }
                            }
                        }
                        
                        // Reset knife position for next shot
                        flyingKnifeY = 0.8f
                    }
                }

                // Update particles
                val iterator = particles.iterator()
                while (iterator.hasNext()) {
                    val p = iterator.next()
                    p.alpha -= 0.04f
                    p.alpha = p.alpha.coerceAtLeast(0f)
                    // Move
                    // Convert normalized motion coordinates
                    // No screen properties here, we edit variables
                    var tmpx = p.x + p.vx
                    var tmpy = p.y + p.vy
                    // We modify in place
                    // Because VisualParticle is a data class with var alpha, we can set values
                    // Let's reflect changes by using standard assignments or copying if needed. It's safe since it's a list.
                    if (p.alpha <= 0) {
                        iterator.remove()
                    }
                }

                delay(16) // ~60fps updates
            }
        }
    }

    // Visual design: Premium Neon Dark Esports theme
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        Color(0xFF0F0C1B), // Midnight deep indigo
                        Color(0xFF1D0E35), // Royal dark purple
                        Color(0xFF2C0F4D)  // Vibrant fusion purple
                    )
                )
            )
    ) {
        // Starry backdrop elements or circles
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height

            // Neon glowing back aura
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(Color(0x3B6C289E), Color.Transparent),
                    center = Offset(w * 0.5f, h * coreCenterY),
                    radius = w * 0.6f
                ),
                center = Offset(w * 0.5f, h * coreCenterY),
                radius = w * 0.6f
            )

            // Dynamic sparks/particles rendering
            particles.forEach { p ->
                drawCircle(
                    color = p.color.copy(alpha = p.alpha),
                    radius = p.size,
                    center = Offset(p.x * w + (p.vx * p.alpha * w * 1.5f), p.y * h + (p.vy * p.alpha * h * 1.5f))
                )
            }
        }

        // Top Navigation & Stats Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = { onBack() },
                modifier = Modifier
                    .clip(CircleShape)
                    .background(Color(0x22FFFFFF))
            ) {
                Text("✕", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            }

            // Game Logo Badge
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0x15FFFFFF))
                    .padding(horizontal = 12.dp, vertical = 6.dp)
            ) {
                Text(
                    "ENERGY CORPS",
                    color = Color(0xFFFFD700),
                    fontSize = 13.sp,
                    fontWeight = FontWeight.ExtraBold,
                    letterSpacing = 1.sp
                )
            }

            // Coin prize pool indicator
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0x33FFB300)),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.shadow(8.dp, RoundedCornerShape(16.dp))
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("🪙 ", fontSize = 14.sp)
                    Text(
                        "Prize: ${entryFee * 3}",
                        color = Color(0xFFFFD700),
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        // HUD Dashboard overlays (Score, levels, ammunition)
        Column(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = 90.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                "SCORE",
                color = Color.White.copy(alpha = 0.5f),
                fontSize = 13.sp,
                fontWeight = FontWeight.Medium,
                letterSpacing = 2.sp
            )
            Text(
                "$score",
                color = Color.White,
                fontSize = 44.sp,
                fontWeight = FontWeight.Black
            )
            Spacer(modifier = Modifier.height(4.dp))
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                Badge(
                    containerColor = Color(0xFF00C853),
                    modifier = Modifier.padding(end = 6.dp)
                ) {
                    Text(
                        "LEVEL $currentLevel",
                        color = Color.White,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 4.dp)
                    )
                }
                Text(
                    "Target: $knivesToEmbed Knives",
                    color = Color.White.copy(alpha = 0.8f),
                    fontSize = 12.sp
                )
            }
        }

        // Interactive Gaming Space Canvas
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .clickable(
                    indication = null,
                    interactionSource = remember { MutableInteractionSource() }
                ) {
                    if (gameState == "PLAYING" && !isKnifeFlying) {
                        isKnifeFlying = true
                        flyingKnifeY = 0.8f
                    }
                }
        ) {
            val w = size.width
            val h = size.height
            val diskRadius = w * 0.22f
            val centerOffset = Offset(w * 0.5f, h * coreCenterY)

            // --- 1. RENDER SPINNING WOOD ENERGY DECK ---
            rotate(degrees = coreRotationAngle, pivot = centerOffset) {
                // Outer Ring
                drawCircle(
                    color = Color(0xFF6C289E),
                    radius = diskRadius + 15f,
                    center = centerOffset,
                    style = strokeLight()
                )
                
                // Outer Solid Rim (Neon Cyan/Purple)
                drawCircle(
                    brush = Brush.sweepGradient(
                        colors = listOf(Color(0xFF00F5FF), Color(0xFF6C289E), Color(0xFFFF007F), Color(0xFF00F5FF)),
                        center = centerOffset
                    ),
                    radius = diskRadius,
                    center = centerOffset
                )

                // Concentric inner ring
                drawCircle(
                    color = Color(0xFF0F0C1B),
                    radius = diskRadius * 0.82f,
                    center = centerOffset
                )

                // Sub-ring for aesthetic
                drawCircle(
                    color = Color(0xFFFF007F).copy(alpha = 0.4f),
                    radius = diskRadius * 0.7f,
                    center = centerOffset,
                    style = strokeLight(4f)
                )

                // Energy Core target points (little glowing spots on the rim style)
                for (a in 0 until 360 step 60) {
                    val rad = (a * PI / 180).toFloat()
                    val coreSpotX = centerOffset.x + (diskRadius * 0.85f) * cos(rad)
                    val coreSpotY = centerOffset.y + (diskRadius * 0.85f) * sin(rad)
                    drawCircle(
                        color = Color(0xFF00F5FF),
                        radius = 8f,
                        center = Offset(coreSpotX, coreSpotY)
                    )
                }

                // Inner core core glow
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(Color(0xFFFF007F), Color(0xFF2C0F4D)),
                        center = centerOffset,
                        radius = diskRadius * 0.35f
                    ),
                    radius = diskRadius * 0.35f,
                    center = centerOffset
                )

                // --- 2. RENDER EMBEDDED SPEARS/KNIVES ---
                embeddedKnives.forEach { knife ->
                    // Knife is pointing from outside TOWARDS the center.
                    // Embedded knife angle is knife.initialAngle.
                    // Let's rotate so that we can draw it simply pointing downwards at the bottom of core
                    rotate(degrees = knife.initialAngle - 90f, pivot = centerOffset) {
                        // Drawing knife handle & blade pointing up into the surface
                        val bladeLength = 65f
                        val bladeWidth = 10f
                        val handleLength = 35f

                        // Blade (Glowing gradient spear)
                        val bladeTop = Offset(w * 0.5f, centerOffset.y + diskRadius - 5f)
                        val bladeBottom = Offset(w * 0.5f, centerOffset.y + diskRadius + bladeLength)
                        
                        drawLine(
                            brush = Brush.verticalGradient(
                                colors = listOf(Color(0xFF00F5FF), Color(0xFFFF007F))
                            ),
                            start = bladeTop,
                            end = bladeBottom,
                            strokeWidth = bladeWidth,
                            cap = StrokeCap.Round
                        )

                        // Glowing Guard
                        drawCircle(
                            color = Color(0xFFFFFFFF),
                            radius = 9f,
                            center = bladeBottom
                        )

                        // Handle
                        drawLine(
                            color = Color(0xFFCCCCCC),
                            start = bladeBottom,
                            end = Offset(w * 0.5f, bladeBottom.y + handleLength),
                            strokeWidth = 6f
                        )
                    }
                }
            }

            // --- 3. RENDER AMMUNITION / SHOTS REMAINING OVERLAYS ---
            // Draw indicators of spear count on bottom left
            val bulletIconOffset = Offset(150f, h * 0.65f)
            // Left margin
            // We can draw mini spears representation
            
            // --- 4. RENDER FLYING SPEAR / KNIFE ---
            if (gameState == "PLAYING" || isKnifeFlying) {
                val fY = flyingKnifeY * h
                val bladeTop = Offset(w * 0.5f, fY)
                val bladeBottom = Offset(w * 0.5f, fY + 65f)
                val handleBottom = Offset(w * 0.5f, fY + 100f)

                // Glow trail behind flying knife
                if (isKnifeFlying) {
                    drawLine(
                        color = Color(0x7F00F5FF),
                        start = Offset(w * 0.5f, fY + 50f),
                        end = Offset(w * 0.5f, fY + 220f),
                        strokeWidth = 14f,
                        cap = StrokeCap.Round
                    )
                }

                // Laser Blade
                drawLine(
                    brush = Brush.verticalGradient(
                        colors = listOf(Color(0xFF00F5FF), Color(0xFFFFFFFF))
                    ),
                    start = bladeTop,
                    end = bladeBottom,
                    strokeWidth = 12f,
                    cap = StrokeCap.Round
                )
                
                // Guard ring
                drawCircle(
                    color = Color(0xFFFFFFFF),
                    radius = 9f,
                    center = bladeBottom
                )

                // Handle
                drawLine(
                    color = Color(0xFF888888),
                    start = bladeBottom,
                    end = handleBottom,
                    strokeWidth = 7f
                )
            }
        }

        // Ammunition bottom indicator
        Row(
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(start = 32.dp, bottom = 48.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                "KNIVES: ",
                color = Color.White.copy(alpha = 0.5f),
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp
            )
            repeat(knivesToEmbed) { index ->
                val active = index < knivesRemaining
                Box(
                    modifier = Modifier
                        .padding(horizontal = 3.dp)
                        .size(width = 6.dp, height = 22.dp)
                        .clip(RoundedCornerShape(3.dp))
                        .background(
                            if (active) Color(0xFF00F5FF) else Color(0x33FFFFFF)
                        )
                )
            }
        }

        // Tap To Shoot Callout
        if (gameState == "PLAYING" && !isKnifeFlying) {
            Box(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = 40.dp)
            ) {
                Text(
                    "▼ TAP TO LAUNCH COMPACT SPEAR ▼",
                    color = Color(0xFF00F5FF).copy(alpha = 0.6f),
                    fontSize = 12.sp,
                    fontWeight = FontWeight.ExtraBold,
                    letterSpacing = 1.5.sp
                )
            }
        }

        // SCREEN STATES (Intro, GameOver, Victory modals)

        if (gameState == "INTRO") {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0xEE0B0914))
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth(0.88f)
                        .shadow(16.dp, RoundedCornerShape(24.dp)),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1435)),
                    shape = RoundedCornerShape(24.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            "⚡ SHOT ENERGY ⚡",
                            color = Color(0xFF00F5FF),
                            fontSize = 24.sp,
                            fontWeight = FontWeight.Black
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            "Tap to launch your quantum spears at the rotating power core. Do not hit other spears!",
                            color = Color.White.copy(alpha = 0.75f),
                            fontSize = 14.sp,
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                            modifier = Modifier.padding(horizontal = 8.dp)
                        )
                        Spacer(modifier = Modifier.height(20.dp))
                        
                        Divider(color = Color.White.copy(alpha = 0.1f))
                        Spacer(modifier = Modifier.height(16.dp))

                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Wager Code:", color = Color.White.copy(alpha = 0.6f))
                            Text("🪙 $entryFee Coins", color = Color(0xFFFFD700), fontWeight = FontWeight.Bold)
                        }
                        
                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth().padding(top = 4.dp)
                        ) {
                            Text("Est. Victory Reward:", color = Color.White.copy(alpha = 0.6f))
                            Text("🪙 ${entryFee * 3} Coins", color = Color(0xFF00FF87), fontWeight = FontWeight.Bold)
                        }

                        Spacer(modifier = Modifier.height(24.dp))

                        Button(
                            onClick = {
                                gameState = "PLAYING"
                                knivesToEmbed = 6
                                knivesRemaining = 6
                                currentLevel = 1
                                score = 0
                                embeddedKnives.clear()
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00F5FF)),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Filled.PlayArrow, contentDescription = "Play", tint = Color.Black)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("START MATCH", color = Color.Black, fontWeight = FontWeight.Black)
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        TextButton(onClick = { onBack() }) {
                            Text("CANCEL", color = Color.White.copy(alpha = 0.5f))
                        }
                    }
                }
            }
        }

        if (gameState == "GAMEOVER") {
            val finalWinnings = if (score > 100) entryFee * 1.5 else 0.0
            GameOutcomeOverlay(
                isSuccess = false,
                titleText = "💥 COLLISION FAILURE!",
                subtitleText = "You struck an existing spear. The reactor core overloaded!",
                score = score,
                rewardText = if (finalWinnings > 0) "🪙 +$finalWinnings" else "🪙 0.0 (Failed)",
                buttonText = "COLLECT PRIZE & EXIT",
                onConfirm = {
                    onGameOver(score, finalWinnings)
                }
            )
        }

        if (gameState == "VICTORY") {
            val winWinnings = entryFee * 3.5
            GameOutcomeOverlay(
                isSuccess = true,
                titleText = "🏆 SYSTEM OVERPOWERED 🏆",
                subtitleText = "You completed all core levels! Power Grid has been stabilized.",
                score = score,
                rewardText = "🪙 +$winWinnings Coins",
                buttonText = "CLAIM WALLET BONUS & EXIT",
                onConfirm = {
                    onGameOver(score, winWinnings)
                }
            )
        }
    }
}

private fun strokeLight(width: Float = 3f) = androidx.compose.ui.graphics.drawscope.Stroke(
    width = width,
    pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 10f), 0f)
)
