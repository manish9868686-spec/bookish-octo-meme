package com.example.games

import android.os.SystemClock
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.cos
import kotlin.math.sin
import com.example.ui.GameOutcomeOverlay


data class LaserBeam(
    var xPercent: Float,
    var yPercent: Float,
    var isAlive: Boolean = true
)

data class Asteroid(
    val id: Long = Math.random().toLong(),
    var xPercent: Float,
    var yPercent: Float,
    val speed: Float,
    val sizeRadius: Float, // size in dp equivalent scale
    val scoreVal: Int = 15,
    var isAlive: Boolean = true
)

data class Spark(
    val xPercent: Float,
    val yPercent: Float,
    val vx: Float,
    val vy: Float,
    val color: Color,
    var age: Float = 1.0f
)

@Composable
fun SpaceShooterGameScreen(
    entryFee: Double,
    onGameOver: (score: Int, prizeWon: Double) -> Unit,
    onBack: () -> Unit
) {
    val scope = rememberCoroutineScope()
    
    // States: "INTRO", "PLAYING", "GAMEOVER", "VICTORY"
    var gameState by remember { mutableStateOf("INTRO") }
    var score by remember { mutableIntStateOf(0) }
    var lives by remember { mutableIntStateOf(3) }
    var level by remember { mutableIntStateOf(1) }
    
    // Player ship X coordinate percentage (0.0 to 1.0)
    var playerXPercent by remember { mutableStateOf(0.5f) }
    
    // Game item lists
    val lasers = remember { mutableStateListOf<LaserBeam>() }
    val asteroids = remember { mutableStateListOf<Asteroid>() }
    val sparks = remember { mutableStateListOf<Spark>() }

    // Floating particles (background space dust stars)
    val backgroundStars = remember {
        mutableStateListOf<Offset>().apply {
            repeat(30) {
                add(Offset(Math.random().toFloat(), Math.random().toFloat()))
            }
        }
    }

    // Auto-fire and Asteroid spawning loops
    LaunchedEffect(gameState, level) {
        if (gameState == "PLAYING") {
            var lastLaserTime = 0L
            var lastAsteroidTime = 0L
            val laserInterval = 250L // ms
            val asteroidInterval = (1000L - (level * 150L)).coerceAtLeast(350L) // Speeds up as we rank up

            while (gameState == "PLAYING") {
                val now = SystemClock.uptimeMillis()
                
                // Fire Laser
                if (now - lastLaserTime >= laserInterval) {
                    lasers.add(LaserBeam(playerXPercent, 0.85f))
                    lastLaserTime = now
                }

                // Spawn Asteroid
                if (now - lastAsteroidTime >= asteroidInterval) {
                    asteroids.add(
                        Asteroid(
                            xPercent = (Math.random() * 0.9f + 0.05f).toFloat(),
                            yPercent = -0.05f,
                            speed = (0.006f + (Math.random() * 0.007f) + (level * 0.002f)).toFloat(),
                            sizeRadius = (16f + Math.random() * 24f).toFloat() // asteroid size
                        )
                    )
                    lastAsteroidTime = now
                }

                delay(50)
            }
        }
    }

    // Level progression check
    LaunchedEffect(score) {
        if (score > 0 && score % 100 == 0) {
            level = (score / 100) + 1
            if (level > 4) {
                gameState = "VICTORY"
            }
        }
    }

    // Major Game Animation / Update loop running at 60fps
    LaunchedEffect(gameState) {
        if (gameState == "PLAYING") {
            while (gameState == "PLAYING") {
                // Space dust moves slowly down
                backgroundStars.forEachIndexed { idx, star ->
                    var ny = star.y + 0.002f
                    if (ny > 1f) ny = 0f
                    backgroundStars[idx] = Offset(star.x, ny)
                }

                // 1. Update Lasers
                val laserIterator = lasers.iterator()
                while (laserIterator.hasNext()) {
                    val l = laserIterator.next()
                    l.yPercent -= 0.025f // Move up
                    if (l.yPercent < 0f || !l.isAlive) {
                        laserIterator.remove()
                    }
                }

                // 2. Update Asteroids
                val asteroidIterator = asteroids.iterator()
                while (asteroidIterator.hasNext()) {
                    val ast = asteroidIterator.next()
                    ast.yPercent += ast.speed // Move down

                    // Collision check with play ship
                    // Normal ship center: playerXPercent, yPercent = 0.88f
                    val dx = ast.xPercent - playerXPercent
                    val dy = ast.yPercent - 0.88f
                    val distanceSq = dx * dx + dy * dy
                    
                    if (distanceSq < 0.0035f) { // Collision with player ship!
                        lives--
                        ast.isAlive = false
                        asteroidIterator.remove()
                        
                        // Create Shield Spark Blast
                        repeat(15) {
                            sparks.add(
                                Spark(
                                    xPercent = playerXPercent,
                                    yPercent = 0.88f,
                                    vx = (-0.02f + Math.random() * 0.04f).toFloat(),
                                    vy = (-0.01f - Math.random() * 0.02f).toFloat(),
                                    color = Color(0xFF00E5FF) // Blue shield glow
                                )
                            )
                        }

                        if (lives <= 0) {
                            gameState = "GAMEOVER"
                        }
                        continue
                    }

                    // Check bounds boundary
                    if (ast.yPercent > 1.05f) {
                        // Asteroid escaped! Deduct 1 score token to penalize missing targets
                        score = (score - 5).coerceAtLeast(0)
                        asteroidIterator.remove()
                        continue
                    }
                }

                // 3. Collision Checks Between Lasers & Asteroids
                lasers.forEach { laser ->
                    if (!laser.isAlive) return@forEach
                    asteroids.forEach { ast ->
                        if (!ast.isAlive) return@forEach
                        
                        // Distance check between laser and asteroid
                        val ldx = laser.xPercent - ast.xPercent
                        val ldy = laser.yPercent - ast.yPercent
                        val ldistSq = ldx * ldx + ldy * ldy
                        
                        if (ldistSq < 0.0022f) { // HIT!
                            laser.isAlive = false
                            ast.isAlive = false
                            score += ast.scoreVal
                            
                            // Explosion sparks
                            repeat(8) {
                                sparks.add(
                                    Spark(
                                        xPercent = ast.xPercent,
                                        yPercent = ast.yPercent,
                                        vx = (-0.015f + Math.random() * 0.03f).toFloat(),
                                        vy = (-0.015f + Math.random() * 0.03f).toFloat(),
                                        color = Color(0xFFFF5252) // Orange-red explosion
                                    )
                                )
                            }
                        }
                    }
                }

                // Filter out dead asteroids
                asteroids.removeAll { !it.isAlive }

                // 4. Update Sparks
                val sparkIterator = sparks.iterator()
                while (sparkIterator.hasNext()) {
                    val s = sparkIterator.next()
                    s.age -= 0.05f
                    if (s.age <= 0f) {
                        sparkIterator.remove()
                    }
                }

                delay(16) // ~60fps
            }
        }
    }

    // Gaming Page
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        Color(0xFF020210), // Deep pure space black
                        Color(0xFF0D0D2E), // Cosmic blue-black
                        Color(0xFF1E103E)  // Celestial indigo
                    )
                )
            )
            .pointerInput(gameState) {
                if (gameState == "PLAYING") {
                    detectDragGestures { change, dragAmount ->
                        change.consume()
                        // Update ship position ratio based on drag amount
                        val screenWidth = size.width.toFloat()
                        if (screenWidth > 0) {
                            val addition = dragAmount.x / screenWidth
                            playerXPercent = (playerXPercent + addition).coerceIn(0.06f, 0.94f)
                        }
                    }
                }
            }
    ) {
        
        // Stars and game objects rendering area
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height

            // 1. Draw Space background stars
            backgroundStars.forEach { star ->
                drawCircle(
                    color = Color.White.copy(alpha = 0.5f),
                    radius = 3f,
                    center = Offset(star.x * w, star.y * h)
                )
            }

            // Aesthetical Nebula Backlight
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(Color(0x228B5CF6), Color.Transparent),
                    center = Offset(w * 0.5f, h * 0.5f),
                    radius = w * 0.7f
                ),
                center = Offset(w * 0.5f, h * 0.5f),
                radius = w * 0.7f
            )

            // 2. Draw Laser Beams
            lasers.forEach { laser ->
                drawLine(
                    color = Color(0xFFFFEB3B),
                    start = Offset(laser.xPercent * w, (laser.yPercent - 0.02f) * h),
                    end = Offset(laser.xPercent * w, laser.yPercent * h),
                    strokeWidth = 10f,
                    cap = StrokeCap.Round
                )
                
                // Cyan spark core
                drawLine(
                    color = Color.White,
                    start = Offset(laser.xPercent * w, (laser.yPercent - 0.015f) * h),
                    end = Offset(laser.xPercent * w, laser.yPercent * h),
                    strokeWidth = 5f,
                    cap = StrokeCap.Round
                )
            }

            // 3. Draw Asteroids
            asteroids.forEach { ast ->
                val px = ast.xPercent * w
                val py = ast.yPercent * h
                val rad = ast.sizeRadius * 1.5f

                // Glow ring
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(Color(0xAAFF5722), Color.Transparent),
                        center = Offset(px, py),
                        radius = rad * 1.4f
                    ),
                    radius = rad * 1.4f,
                    center = Offset(px, py)
                )

                // Asteroid crater silhouette
                drawCircle(
                    color = Color(0xFFE64A19),
                    radius = rad,
                    center = Offset(px, py)
                )

                // Minor crater details inside
                drawCircle(
                    color = Color(0xFFD84315),
                    radius = rad * 0.35f,
                    center = Offset(px - rad * 0.3f, py - rad * 0.2f)
                )

                drawCircle(
                    color = Color(0xFFBF360C),
                    radius = rad * 0.2f,
                    center = Offset(px + rad * 0.4f, py + rad * 0.3f)
                )
            }

            // 4. Draw Sparks / Explosion particles
            sparks.forEach { spark ->
                val sx = (spark.xPercent + spark.vx * (1f - spark.age) * 6f) * w
                val sy = (spark.yPercent + spark.vy * (1f - spark.age) * 6f) * h
                drawCircle(
                    color = spark.color.copy(alpha = spark.age),
                    radius = 8f * spark.age,
                    center = Offset(sx, sy)
                )
            }

            // 5. Draw Spaceship (glowing metallic cyber-design)
            val shipX = playerXPercent * w
            val shipY = 0.88f * h
            
            // Jet engines flame (pulsing)
            val flameHeight = 35f + (Math.random() * 15f).toFloat()
            drawPath(
                path = Path().apply {
                    moveTo(shipX - 12f, shipY + 25f)
                    lineTo(shipX, shipY + 25f + flameHeight)
                    lineTo(shipX + 12f, shipY + 25f)
                    close()
                },
                brush = Brush.verticalGradient(
                    colors = listOf(Color(0xFFFFEA3B), Color(0xFFFF5722), Color.Transparent)
                )
            )

            // Wing Left
            drawPath(
                path = Path().apply {
                    moveTo(shipX - 45f, shipY + 22f)
                    lineTo(shipX - 15f, shipY - 5f)
                    lineTo(shipX - 15f, shipY + 22f)
                    close()
                },
                color = Color(0xFF4A148C)
            )

            // Wing Right
            drawPath(
                path = Path().apply {
                    moveTo(shipX + 45f, shipY + 22f)
                    lineTo(shipX + 15f, shipY - 5f)
                    lineTo(shipX + 15f, shipY + 22f)
                    close()
                },
                color = Color(0xFF4A148C)
            )

            // Cyber Cannons on wings
            drawLine(Color(0xFFE040FB), Offset(shipX - 35f, shipY + 10f), Offset(shipX - 35f, shipY - 20f), strokeWidth = 6f, cap = StrokeCap.Round)
            drawLine(Color(0xFFE040FB), Offset(shipX + 35f, shipY + 10f), Offset(shipX + 35f, shipY - 20f), strokeWidth = 6f, cap = StrokeCap.Round)

            // Main Fuselage (Aesthetic Shield polygon)
            drawPath(
                path = Path().apply {
                    moveTo(shipX, shipY - 35f) // nose
                    lineTo(shipX + 22f, shipY + 15f) // bottom right
                    lineTo(shipX - 22f, shipY + 15f) // bottom left
                    close()
                },
                color = Color(0xFFE040FB)
            )

            // Nose Shield glow
            drawPath(
                path = Path().apply {
                    moveTo(shipX, shipY - 25f)
                    lineTo(shipX + 10f, shipY + 5f)
                    lineTo(shipX - 10f, shipY + 5f)
                    close()
                },
                color = Color(0xFFEEFF41)
            )
        }

        // HUD Top layout (Navigation back, life meters, scores)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = { onBack() },
                modifier = Modifier
                    .clip(CircleShape)
                    .background(Color(0x22FFFFFF))
            ) {
                Text("✕", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            }

            // Life Shield Deck
            Row(
                modifier = Modifier
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color(0x18FFFFFF))
                    .padding(horizontal = 12.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("🛡️ ", fontSize = 12.sp)
                repeat(3) { index ->
                    val active = index < lives
                    Box(
                        modifier = Modifier
                            .padding(horizontal = 3.dp)
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(
                                if (active) Color(0xFF00E5FF) else Color(0x33FFFFFF)
                            )
                    )
                }
            }

            // Coin value Pool
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0x449C27B0)),
                shape = RoundedCornerShape(16.dp)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("🪙 ", fontSize = 13.sp)
                    Text(
                        "Prize: ${entryFee * 3}",
                        color = Color(0xFFFFD700),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        // Level and Score Labels
        Column(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = 90.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                "SCORE",
                color = Color.White.copy(alpha = 0.5f),
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.5.sp
            )
            Text(
                "$score",
                color = Color.White,
                fontSize = 42.sp,
                fontWeight = FontWeight.Black
            )
            Spacer(modifier = Modifier.height(4.dp))
            Badge(containerColor = Color(0xFFD500F9)) {
                Text(
                    "SECTOR LEVEL $level",
                    color = Color.White,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                )
            }
        }

        // Tap Drag Controls Callout
        if (gameState == "PLAYING") {
            Box(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = 32.dp)
            ) {
                Text(
                    "◄ SWIPE HORIZONTALLY TO NAVIGATE STARSHIP ►",
                    color = Color(0xFFE040FB).copy(alpha = 0.6f),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.ExtraBold,
                    letterSpacing = 1.5.sp
                )
            }
        }

        // POP-UP SCREENS

        if (gameState == "INTRO") {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0xFA04040A))
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth(0.88f)
                        .shadow(16.dp, RoundedCornerShape(24.dp)),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF130E29)),
                    shape = RoundedCornerShape(24.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            "🌌 RETRO STARFIGHTER 🌌",
                            color = Color(0xFFE040FB),
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Black
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            "Drag the spaceships horizontally to dodge and incinerate incoming deep space meteors.",
                            color = Color.White.copy(alpha = 0.8f),
                            fontSize = 13.sp,
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                            modifier = Modifier.padding(horizontal = 6.dp)
                        )
                        Spacer(modifier = Modifier.height(20.dp))
                        
                        Divider(color = Color.White.copy(alpha = 0.1f))
                        Spacer(modifier = Modifier.height(16.dp))

                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Wager Stakes:", color = Color.White.copy(alpha = 0.6f))
                            Text("🪙 $entryFee Coins", color = Color(0xFFFFD700), fontWeight = FontWeight.Bold)
                        }
                        
                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth().padding(top = 4.dp)
                        ) {
                            Text("Victory Pot size:", color = Color.White.copy(alpha = 0.6f))
                            Text("🪙 ${entryFee * 3} Coins", color = Color(0xFF00FF87), fontWeight = FontWeight.Bold)
                        }

                        Spacer(modifier = Modifier.height(24.dp))

                        Button(
                            onClick = {
                                gameState = "PLAYING"
                                score = 0
                                level = 1
                                lives = 3
                                playerXPercent = 0.5f
                                lasers.clear()
                                asteroids.clear()
                                sparks.clear()
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE040FB)),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Filled.PlayArrow, contentDescription = null, tint = Color.White)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("PAY ENTRY & LAUNCH", color = Color.White, fontWeight = FontWeight.Black, letterSpacing = 0.5.sp)
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        TextButton(onClick = { onBack() }) {
                            Text("CANCEL", color = Color.White.copy(alpha = 0.4f))
                        }
                    }
                }
            }
        }

        if (gameState == "GAMEOVER") {
            val endPrize = if (score >= 150) entryFee * 1.5 else 0.0
            GameOutcomeOverlay(
                isSuccess = false,
                titleText = "🚨 ESCAPE SHIP DEMOLISHED",
                subtitleText = "We lost ship containment. Meteor strikes compromised defensive hulls.",
                score = score,
                rewardText = if (endPrize > 0) "🪙 +$endPrize" else "🪙 0.0 (Below cutoff)",
                buttonText = "SAVE SCORE & RETURN",
                onConfirm = {
                    onGameOver(score, endPrize)
                }
            )
        }

        if (gameState == "VICTORY") {
            val rewardWinnings = entryFee * 4.0
            GameOutcomeOverlay(
                isSuccess = true,
                titleText = "☄️ METEOR SHIELD OVERPOWERED!",
                subtitleText = "You cleared all meteor waves successfully! Cosmic balance has been restored.",
                score = score,
                rewardText = "🪙 +$rewardWinnings Coins",
                buttonText = "CLAIM CASH PRIZE & DEPART",
                onConfirm = {
                    onGameOver(score, rewardWinnings)
                }
            )
        }
    }
}
