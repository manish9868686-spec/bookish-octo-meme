package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class GameViewModel(application: Application) : AndroidViewModel(application) {
    private val db = GameDatabase.getDatabase(application)
    private val dao = db.gameDao()

    // Expose UI flow for User Profile
    val userFlow: StateFlow<UserUiState> = dao.getUserFlow()
        .map { entity ->
            entity?.toUserUiState() ?: UserUiState()
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = UserUiState()
        )

    // Expose all matches / tournament history logs
    val matchesFlow: StateFlow<List<GameMatchEntity>> = dao.getAllMatchesFlow()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    // Current selected game for Leaderboards state
    private val _selectedLeaderboardGame = MutableStateFlow("Laser Target Hit")
    val selectedLeaderboardGame: StateFlow<String> = _selectedLeaderboardGame.asStateFlow()

    // Expose leaderboard list for the selected game
    val leaderboardFlow: StateFlow<List<LeaderboardEntity>> = _selectedLeaderboardGame
        .flatMapLatest { game ->
            dao.getLeaderboardForGameFlow(game)
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    init {
        // Run seed operations on startup
        viewModelScope.launch {
            seedInitialDataIfNeeded()
        }
    }

    private suspend fun seedInitialDataIfNeeded() = withContext(Dispatchers.IO) {
        // 1. Seed User if absent
        val existingUser = dao.getUserSync()
        if (existingUser == null) {
            dao.insertUser(
                UserEntity(
                    id = 1,
                    name = "Gaming Champion",
                    avatarIndex = 1,
                    coins = 150.0, // starts with coin balance
                    tickets = 5,
                    xp = 0,
                    level = 1,
                    lastSpinTimestamp = 0L
                )
            )
        }

        // 2. Seed default leaderboards if empty
        val existingLeaders = dao.getAllLeaderboardFlow().first()
        if (existingLeaders.isEmpty()) {
            val games = listOf("Laser Target Hit", "Cosmic Starfighter")
            val botAvatars = listOf(2, 3, 4, 1, 2)
            
            games.forEach { game ->
                val bots = listOf(
                    LeaderboardEntity(gameName = game, playerName = "WinZO_King", score = 380, avatarIndex = botAvatars[0], isUser = false, rank = 1),
                    LeaderboardEntity(gameName = game, playerName = "PixelStrike", score = 250, avatarIndex = botAvatars[1], isUser = false, rank = 2),
                    LeaderboardEntity(gameName = game, playerName = "AlphaCoders", score = 180, avatarIndex = botAvatars[2], isUser = false, rank = 3),
                    LeaderboardEntity(gameName = game, playerName = "ArcadeRuler9", score = 120, avatarIndex = botAvatars[3], isUser = false, rank = 4),
                    LeaderboardEntity(gameName = game, playerName = "NinjaGamer", score = 70, avatarIndex = botAvatars[4], isUser = false, rank = 5)
                )
                dao.insertLeaderboardItems(bots)
            }
        }
    }

    fun selectLeaderboardGame(game: String) {
        _selectedLeaderboardGame.value = game
    }

    // Spend coins/tickets to join a game
    fun deductEntryFee(fee: Double, useTicket: Boolean = false): Boolean {
        var success = false
        viewModelScope.launch {
            val user = dao.getUserSync() ?: return@launch
            if (useTicket) {
                if (user.tickets >= 1) {
                    val updated = user.copy(tickets = user.tickets - 1)
                    dao.insertUser(updated)
                    success = true
                }
            } else {
                if (user.coins >= fee) {
                    val updated = user.copy(coins = user.coins - fee)
                    dao.insertUser(updated)
                    success = true
                }
            }
        }.invokeOnCompletion { }
        return true // For simple synchronous UI validation let's proceed, we double check balances inside Screen
    }

    // Give rewards config
    fun addCoins(amount: Double) {
        viewModelScope.launch {
            val user = dao.getUserSync() ?: return@launch
            dao.insertUser(user.copy(coins = user.coins + amount))
        }
    }

    fun addTicket() {
        viewModelScope.launch {
            val user = dao.getUserSync() ?: return@launch
            dao.insertUser(user.copy(tickets = user.tickets + 1))
        }
    }

    fun updateProfileNameAndAvatar(newName: String, newAvatar: Int) {
        viewModelScope.launch {
            val user = dao.getUserSync() ?: return@launch
            dao.insertUser(user.copy(name = newName, avatarIndex = newAvatar))
        }
    }

    // Spin results config
    fun claimSpinReward(rewardText: String, rewardCoins: Double, rewardTickets: Int) {
        viewModelScope.launch {
            val user = dao.getUserSync() ?: return@launch
            val now = System.currentTimeMillis()
            val finalCoins = user.coins + rewardCoins
            val finalTickets = user.tickets + rewardTickets
            
            dao.insertUser(
                user.copy(
                    coins = finalCoins,
                    tickets = finalTickets,
                    lastSpinTimestamp = now
                )
            )
        }
    }

    // Reset spin for testing demonstration
    fun resetSpinTimestamp() {
        viewModelScope.launch {
            val user = dao.getUserSync() ?: return@launch
            dao.insertUser(user.copy(lastSpinTimestamp = 0L))
        }
    }

    // Save final game score, issue payouts and level up
    fun saveGameResult(
        gameName: String,
        entryFee: Double,
        score: Int,
        prizeWon: Double
    ) {
        viewModelScope.launch {
            // 1. Fetch user
            val user = dao.getUserSync() ?: return@launch
            
            // 2. Calculate next level values (XP mechanism)
            val gainedXp = (score * 1.5).toInt()
            var currentXp = user.xp + gainedXp
            var currentLevel = user.level
            var coinsAwardValue = user.coins + prizeWon
            
            // LevelUp boundary formula: NextLevelXP = level * 150
            val xpNeeded = currentLevel * 150
            if (currentXp >= xpNeeded) {
                currentXp -= xpNeeded
                currentLevel++
                coinsAwardValue += 40.0 // Level up reward coins!
            }

            // 3. Update user profile inside DB
            val updatedUser = user.copy(
                coins = coinsAwardValue,
                xp = currentXp,
                level = currentLevel
            )
            dao.insertUser(updatedUser)

            // 4. Save history entry log
            val matchLog = GameMatchEntity(
                gameName = gameName,
                entryFee = entryFee,
                score = score,
                prizeWon = prizeWon,
                status = if (prizeWon > entryFee) "WON" else "COMPLETED",
                timestamp = System.currentTimeMillis()
            )
            dao.insertMatch(matchLog)

            // 5. Update/Add User highscore on Leaderboards
            val userLeaderboardRecord = LeaderboardEntity(
                gameName = gameName,
                playerName = user.name,
                score = score,
                avatarIndex = user.avatarIndex,
                isUser = true,
                rank = 0 // Evaluated dynamically at flow retrieval, or simple index count
            )
            
            // Fetch current game leaderboard rows
            val currentRankings = dao.getAllLeaderboardFlow().first()
                .filter { it.gameName == gameName }
            
            // Filter out user's previous entries for clean stats
            val cleanRankings = currentRankings.filter { !it.isUser }
            
            // Concat user and re-sort
            val newRankings = (cleanRankings + userLeaderboardRecord)
                .sortedByDescending { it.score }
                .take(6) // keep top 6
                .mapIndexed { idx, entity ->
                    entity.copy(rank = idx + 1)
                }

            // Clear database tables and re-insert ranking logs
            dao.deleteLeaderboardForGame(gameName)
            dao.insertLeaderboardItems(newRankings)
        }
    }
}
