package com.example.ui

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

// PHYSICAL PHYSICS PARTICLE FOR CONFETTI / ASHES
data class LiveParticle(
    var x: Float,
    var y: Float,
    var vx: Float,
    var vy: Float,
    var size: Float,
    var color: Color,
    var rotation: Float,
    var rotationSpeed: Float,
    var alpha: Float = 1.0f,
    val isCircle: Boolean = Random.nextBoolean()
)

@Composable
fun GameOutcomeOverlay(
    isSuccess: Boolean,
    titleText: String,
    subtitleText: String,
    score: Int,
    rewardText: String,
    buttonText: String,
    onConfirm: () -> Unit,
    modifier: Modifier = Modifier
) {
    val scope = rememberCoroutineScope()
    
    // --- 1. SPRING SCALE ENTRY ANIMATION (Bouncy framer-motion equivalent) ---
    var animateScale by remember { mutableStateOf(false) }
    val cardScale by animateFloatAsState(
        targetValue = if (animateScale) 1.0f else 0.4f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessLow
        ),
        label = "scale"
    )

    // --- 2. SCREEN-SHAKE PHYSIC ON FAILURE / GLITCH VIBRATION ---
    var shakeX by remember { mutableStateOf(0f) }
    var glitchFlashAlpha by remember { mutableStateOf(0.4f) }

    // --- 3. LIVE PHYSICAL PARTICLE EMITTER SYSTEMS ---
    var particles by remember { mutableStateOf<List<LiveParticle>>(emptyList()) }

    // --- 4. NEON ROTATING GLOW ANGLE ---
    val infiniteTransition = rememberInfiniteTransition(label = "glow")
    val glowAngle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(4000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "glowAngle"
    )

    // Initial Trigger for Particles & Spring scales
    LaunchedEffect(isSuccess) {
        animateScale = true
        
        if (isSuccess) {
            // Spawn 65 vivid colorful confetti expanding from center of screen
            val colors = listOf(
                Color(0xFF00FF87), Color(0xFF00F5FF), Color(0xFFFFD700),
                Color(0xFFFF007F), Color(0xFF9C27B0), Color(0xFFFF5722)
            )
            particles = List(65) {
                val angleRad = Random.nextFloat() * 2f * PI.toFloat()
                val speed = Random.nextFloat() * 18f + 6f
                LiveParticle(
                    x = 0f, // Center relative
                    y = -50f, // slightly offset above card center
                    vx = speed * cos(angleRad),
                    vy = speed * sin(angleRad) - 5f, // push upwards
                    size = Random.nextFloat() * 22f + 8f,
                    color = colors.random(),
                    rotation = Random.nextFloat() * 360f,
                    rotationSpeed = Random.nextFloat() * 12f - 6f
                )
            }

            // Confetti Physics simulation loop running at 60 fps
            while (true) {
                delay(16)
                particles = particles.map { p ->
                    p.copy(
                        x = p.x + p.vx,
                        y = p.y + p.vy,
                        vy = p.vy + 0.38f, // Gravity pull
                        vx = p.vx * 0.98f, // air resistance
                        rotation = p.rotation + p.rotationSpeed,
                        alpha = (p.alpha - 0.006f).coerceAtLeast(0f)
                    )
                }.filter { p -> p.alpha > 0.01f }
                
                if (particles.isEmpty()) break
            }
        } else {
            // FAIL SHAKE physics on start of screen
            scope.launch {
                repeat(8) { step ->
                    val multiplier = (1.0f - (step / 8f))
                    shakeX = if (step % 2 == 0) 24f * multiplier else -24f * multiplier
                    delay(45)
                }
                shakeX = 0f
            }

            // Quick flashing glitch effect
            scope.launch {
                delay(120)
                glitchFlashAlpha = 0f
            }

            // Spawn embers/broken debris falling down slowly
            val colors = listOf(Color(0xFFFF3B30), Color(0xFF551015), Color(0xFF303030), Color(0xFF888888))
            particles = List(35) {
                LiveParticle(
                    x = (Random.nextFloat() * 400f) - 200f,
                    y = -250f,
                    vx = Random.nextFloat() * 4f - 2f,
                    vy = Random.nextFloat() * 3f + 1f,
                    size = Random.nextFloat() * 12f + 6f,
                    color = colors.random(),
                    rotation = Random.nextFloat() * 360f,
                    rotationSpeed = Random.nextFloat() * 4f - 2f
                )
            }

            // Debris Physics Simulation loop
            while (true) {
                delay(16)
                particles = particles.map { p ->
                    p.copy(
                        x = p.x + p.vx,
                        y = p.y + p.vy,
                        vy = p.vy + 0.08f, // very light gravity
                        vx = p.vx + (sin(System.currentTimeMillis() / 200f) * 0.05f), // wind sway
                        rotation = p.rotation + p.rotationSpeed,
                        alpha = (p.alpha - 0.008f).coerceAtLeast(0f)
                    )
                }.filter { p -> p.alpha > 0.01f }
                
                if (particles.isEmpty()) break
            }
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xE6080312))
            .clickable(enabled = false) {}, // Intercept clicks back
        contentAlignment = Alignment.Center
    ) {
        // Draw glitch flash overlay on failure
        if (!isSuccess && glitchFlashAlpha > 0.01f) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0xFFE91E63).copy(alpha = glitchFlashAlpha))
            )
        }

        // Draw dynamic live particles overlay behind card
        Canvas(modifier = Modifier.fillMaxSize()) {
            val centerH = size.width / 2f
            val centerV = size.height / 2f
            
            particles.forEach { p ->
                val pColor = p.color.copy(alpha = p.alpha)
                val drawSize = p.size
                
                // Draw particle with rotation offset
                rotate(degrees = p.rotation, pivot = Offset(centerH + p.x, centerV + p.y)) {
                    if (p.isCircle) {
                        drawCircle(
                            color = pColor,
                            radius = drawSize / 2f,
                            center = Offset(centerH + p.x, centerV + p.y)
                        )
                    } else {
                        drawRect(
                            color = pColor,
                            topLeft = Offset(centerH + p.x - drawSize/2, centerV + p.y - drawSize/2),
                            size = Size(drawSize, drawSize)
                        )
                    }
                }
            }
        }

        // Card modal body with shake offset and spring scaling
        Box(
            modifier = Modifier
                .offset(x = shakeX.dp, y = 0.dp)
                .scale(cardScale)
                .fillMaxWidth(0.9f)
                .shadow(24.dp, RoundedCornerShape(24.dp))
                .clip(RoundedCornerShape(24.dp))
                .background(Color(0xFF130922))
                .border(
                    width = 2.dp,
                    brush = Brush.sweepGradient(
                        colors = if (isSuccess) {
                            listOf(Color(0xFF00FF87), Color(0xFF00F5FF), Color(0xFFFFD700), Color(0xFF00FF87))
                        } else {
                            listOf(Color(0xFFFF3B30), Color(0xFF9C27B0), Color(0xFFFF5252), Color(0xFFFF3B30))
                        }
                    ),
                    shape = RoundedCornerShape(24.dp)
                )
                .padding(2.dp) // Border thickness spacer
                .testTag("outcome_card"),
            contentAlignment = Alignment.Center
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF180D2C))
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Glow Background Icon Circle
                Box(
                    modifier = Modifier
                        .size(80.dp)
                        .clip(CircleShape)
                        .background(
                            Brush.radialGradient(
                                colors = if (isSuccess) {
                                    listOf(Color(0x3300FF87), Color.Transparent)
                                } else {
                                    listOf(Color(0x33FF3B30), Color.Transparent)
                                }
                            )
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    val scaleTransition = rememberInfiniteTransition(label = "iconScale")
                    val iconScale by scaleTransition.animateFloat(
                        initialValue = 0.95f,
                        targetValue = 1.15f,
                        animationSpec = infiniteRepeatable(
                            animation = tween(1100, easing = FastOutSlowInEasing),
                            repeatMode = RepeatMode.Reverse
                        ),
                        label = "pulse"
                    )

                    Text(
                        text = if (isSuccess) "🏆" else "💥",
                        fontSize = 46.sp,
                        modifier = Modifier.scale(iconScale)
                    )
                }

                Spacer(modifier = Modifier.height(18.dp))

                // Title Banner with beautiful text glow styled colors
                Text(
                    text = titleText,
                    color = if (isSuccess) Color(0xFF00FF87) else Color(0xFFFF4081),
                    fontSize = 21.sp,
                    fontWeight = FontWeight.Black,
                    textAlign = TextAlign.Center,
                    letterSpacing = 0.5.sp,
                    modifier = Modifier.testTag("outcome_title")
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Subtitle description Text
                Text(
                    text = subtitleText,
                    color = Color.White.copy(alpha = 0.72f),
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium,
                    textAlign = TextAlign.Center,
                    lineHeight = 18.sp,
                    modifier = Modifier.padding(horizontal = 4.dp)
                )

                Spacer(modifier = Modifier.height(22.dp))

                // Score Details Dashboard Section
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(Color(0xFF0F071F))
                        .border(1.dp, Color(0xFF3F1F6F).copy(alpha = 0.4f), RoundedCornerShape(16.dp))
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "TOTAL SCORE",
                            color = Color.White.copy(alpha = 0.4f),
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Black,
                            letterSpacing = 1.2.sp
                        )
                        Text(
                            text = "$score PTS",
                            color = Color.White,
                            fontSize = 24.sp,
                            fontWeight = FontWeight.Black
                        )
                    }

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(
                                if (isSuccess) Color(0x1F00FF87) else Color(0x1FFF3B30)
                            )
                            .padding(horizontal = 14.dp, vertical = 8.dp)
                    ) {
                        Text(
                            text = rewardText,
                            color = if (isSuccess) Color(0xFF00FF87) else Color(0xFFFF4081),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Black
                        )
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                // Interactive Confirmation Action Call containing Ripple pulse
                Button(
                    onClick = onConfirm,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isSuccess) Color(0xFF00FF87) else Color(0xFFFF4081)
                    ),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("outcome_button")
                ) {
                    Text(
                        text = buttonText,
                        color = if (isSuccess) Color.Black else Color.White,
                        fontWeight = FontWeight.Black,
                        fontSize = 14.sp,
                        letterSpacing = 0.5.sp
                    )
                }
            }
        }
    }
}
