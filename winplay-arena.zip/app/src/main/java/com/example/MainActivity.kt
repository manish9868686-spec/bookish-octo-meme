package com.example

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.GameMatchEntity
import com.example.games.KnifeGameScreen
import com.example.games.SpaceShooterGameScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.viewmodel.GameViewModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                MainAppHost()
            }
        }
    }
}

@Composable
fun MainAppHost() {
    val context = LocalContext.current
    val viewModel: GameViewModel = viewModel()
    val userState by viewModel.userFlow.collectAsState()
    val matches by viewModel.matchesFlow.collectAsState()
    val leaderboard by viewModel.leaderboardFlow.collectAsState()
    val selectedGame by viewModel.selectedLeaderboardGame.collectAsState()

    // Screen navigation managers: "DASHBOARD", "GAME_KNIFE", "GAME_SHOOTER"
    var currentScreen by remember { mutableStateOf("DASHBOARD") }
    var activeWagerFee by remember { mutableDoubleStateOf(10.0) }

    // Dialog & overlay flags
    var showEditProfile by remember { mutableStateOf(false) }
    var showLuckyWheel by remember { mutableStateOf(false) }
    var showAddCoinsDialog by remember { mutableStateOf(false) }

    // Tab manager: 0=Arcade, 1=History, 2=Leaderboards, 3=Refer
    var activeTab by remember { mutableIntStateOf(0) }

    Box(modifier = Modifier.fillMaxSize()) {
        when (currentScreen) {
            "DASHBOARD" -> {
                DashboardScreen(
                    userState = userState,
                    matches = matches,
                    leaderboard = leaderboard,
                    selectedGame = selectedGame,
                    activeTab = activeTab,
                    onTabSelected = { activeTab = it },
                    onEditProfileClick = { showEditProfile = true },
                    onLuckyWheelClick = { showLuckyWheel = true },
                    onAddCoinsClick = { showAddCoinsDialog = true },
                    onSelectLeaderboardGame = { viewModel.selectLeaderboardGame(it) },
                    onStartKnifeGame = { fee ->
                        if (userState.coins >= fee) {
                            viewModel.deductEntryFee(fee)
                            activeWagerFee = fee
                            currentScreen = "GAME_KNIFE"
                        } else {
                            Toast.makeText(context, "Insufficient Game Coins! Add coins from wallet.", Toast.LENGTH_LONG).show()
                            showAddCoinsDialog = true
                        }
                    },
                    onStartShooterGame = { fee ->
                        if (userState.coins >= fee) {
                            viewModel.deductEntryFee(fee)
                            activeWagerFee = fee
                            currentScreen = "GAME_SHOOTER"
                        } else {
                            Toast.makeText(context, "Insufficient Game Coins! Add coins from wallet.", Toast.LENGTH_LONG).show()
                            showAddCoinsDialog = true
                        }
                    }
                )
            }
            "GAME_KNIFE" -> {
                KnifeGameScreen(
                    entryFee = activeWagerFee,
                    onGameOver = { score, prize ->
                        viewModel.saveGameResult("Laser Target Hit", activeWagerFee, score, prize)
                        currentScreen = "DASHBOARD"
                        activeTab = 1 // redirect to historical logs
                    },
                    onBack = {
                        currentScreen = "DASHBOARD"
                    }
                )
            }
            "GAME_SHOOTER" -> {
                SpaceShooterGameScreen(
                    entryFee = activeWagerFee,
                    onGameOver = { score, prize ->
                        viewModel.saveGameResult("Cosmic Starfighter", activeWagerFee, score, prize)
                        currentScreen = "DASHBOARD"
                        activeTab = 1 // redirect to historical logs
                    },
                    onBack = {
                        currentScreen = "DASHBOARD"
                    }
                )
            }
        }

        // --- Dialogs Overlay ---

        if (showEditProfile) {
            EditProfileDialog(
                currentName = userState.name,
                currentAvatar = userState.avatarIndex,
                totalGames = matches.size,
                onDismiss = { showEditProfile = false },
                onSave = { name, avatar ->
                    viewModel.updateProfileNameAndAvatar(name, avatar)
                    showEditProfile = false
                }
            )
        }

        if (showAddCoinsDialog) {
            AddCoinsDialog(
                onDismiss = { showAddCoinsDialog = false },
                onAdd = { coins, usePromo ->
                    viewModel.addCoins(coins)
                    if (usePromo) {
                        viewModel.addTicket()
                    }
                    showAddCoinsDialog = false
                    Toast.makeText(context, "🪙 +$coins Coins added successfully!", Toast.LENGTH_SHORT).show()
                }
            )
        }

        if (showLuckyWheel) {
            LuckyWheelModal(
                lastSpinTime = userState.lastSpinTimestamp,
                onDismiss = { showLuckyWheel = false },
                onClaimReward = { reward, coins, tickets ->
                    viewModel.claimSpinReward(reward, coins, tickets)
                },
                onQuickReset = {
                    viewModel.resetSpinTimestamp()
                }
            )
        }
    }
}

@Composable
fun DashboardScreen(
    userState: com.example.data.UserUiState,
    matches: List<GameMatchEntity>,
    leaderboard: List<com.example.data.LeaderboardEntity>,
    selectedGame: String,
    activeTab: Int,
    onTabSelected: (Int) -> Unit,
    onEditProfileClick: () -> Unit,
    onLuckyWheelClick: () -> Unit,
    onAddCoinsClick: () -> Unit,
    onSelectLeaderboardGame: (String) -> Unit,
    onStartKnifeGame: (Double) -> Unit,
    onStartShooterGame: (Double) -> Unit
) {
    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = Color(0xFF0C0816) // Deep midnight black theme
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Header Arena Panel
            HeaderPanel(
                name = userState.name,
                avatarIndex = userState.avatarIndex,
                level = userState.level,
                xp = userState.xp,
                coins = userState.coins,
                tickets = userState.tickets,
                totalGames = matches.size,
                onEditProfile = onEditProfileClick,
                onAddWallet = onAddCoinsClick
            )

            // Dynamic Lucky Wheel Promo Row
            PromoLuckyCard(onClick = onLuckyWheelClick, lastSpin = userState.lastSpinTimestamp)

            // Scrollable Category Tabs
            CategoryTabBar(activeTab = activeTab, onTabSelected = onTabSelected)

            // Scrollable Active body
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
            ) {
                when (activeTab) {
                    0 -> TabArcadeGames(onStartKnife = onStartKnifeGame, onStartShooter = onStartShooterGame)
                    1 -> TabHistoryList(matches = matches)
                    2 -> TabLeaderboards(
                        leaderboard = leaderboard,
                        selectedGame = selectedGame,
                        onGameSelected = onSelectLeaderboardGame,
                        userState = userState
                    )
                    3 -> TabReferAndEarn()
                }
            }
        }
    }
}

// ------------------------------------
// UI PANELS & SUB-COMPONENTS
// ------------------------------------

@Composable
fun HeaderPanel(
    name: String,
    avatarIndex: Int,
    level: Int,
    xp: Int,
    coins: Double,
    tickets: Int,
    totalGames: Int,
    onEditProfile: () -> Unit,
    onAddWallet: () -> Unit
) {
    val welcomeText = remember {
        val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        when {
            hour < 12 -> "Good Morning ☀️"
            hour < 18 -> "Good Afternoon 🌤️"
            else -> "Good Evening 🌙"
        }
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(
                Brush.verticalGradient(
                    colors = listOf(Color(0xFF230F47), Color(0xFF130827))
                )
            )
            .shadow(4.dp)
            .padding(16.dp)
    ) {
        // Top section
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // Profile Info with circular avatar
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.clickable { onEditProfile() }
            ) {
                PlayerAvatarView(
                    avatarIndex = avatarIndex,
                    size = 54.dp,
                    modifier = Modifier.border(2.dp, Color(0xFFFFD700), CircleShape)
                )
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        welcomeText,
                        color = Color.White.copy(alpha = 0.6f),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            name,
                            color = Color.White,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Black
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Icon(
                            Icons.Filled.Edit,
                            contentDescription = "Edit Profile",
                            tint = Color(0xFFFFD700),
                            modifier = Modifier.size(13.dp)
                        )
                    }
                    
                    // Level Indicator based on total games played
                    val calculatedLevel = (totalGames / 3) + 1
                    val gamesInLevel = totalGames % 3
                    val nextLevelTarget = 3
                    val progressFraction = gamesInLevel.toFloat() / nextLevelTarget.toFloat()

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(top = 2.dp)
                    ) {
                        Text(
                            "Level $calculatedLevel",
                            color = Color(0xFF00FF87),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.ExtraBold,
                            modifier = Modifier.testTag("user_profile_level_badge")
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Box(
                            modifier = Modifier
                                .width(80.dp)
                                .height(6.dp)
                                .clip(RoundedCornerShape(3.dp))
                                .background(Color.White.copy(alpha = 0.15f))
                                .testTag("user_profile_xp_bar_container")
                        ) {
                            Box(
                                modifier = Modifier
                                    .fillMaxHeight()
                                    .fillMaxWidth(fraction = progressFraction.coerceIn(0.01f, 1.0f))
                                    .background(Brush.horizontalGradient(listOf(Color(0xFF00FF87), Color(0xFF00F5FF))))
                                    .testTag("user_profile_xp_bar_progress")
                            )
                        }
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            "$gamesInLevel/$nextLevelTarget GP",
                            color = Color.White.copy(alpha = 0.6f),
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.testTag("user_profile_xp_text")
                        )
                    }
                }
            }

            // Coin and ticket Wallet Badges block
            Row(verticalAlignment = Alignment.CenterVertically) {
                // Game coins summary
                Column(
                    horizontalAlignment = Alignment.End,
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0x22FFFFFF))
                        .clickable { onAddWallet() }
                        .padding(horizontal = 8.dp, vertical = 6.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("🪙", fontSize = 15.sp)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            String.format("%.1f", coins),
                            color = Color(0xFFFFD700),
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Black
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Box(
                            modifier = Modifier
                                .size(16.dp)
                                .clip(CircleShape)
                                .background(Color(0xFFFFD700)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("+", color = Color.Black, fontSize = 11.sp, fontWeight = FontWeight.Black)
                        }
                    }
                    Text(
                        "Coins Wallet",
                        color = Color.White.copy(alpha = 0.5f),
                        fontSize = 9.sp
                    )
                }

                Spacer(modifier = Modifier.width(8.dp))

                // Ticket counter
                Column(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0x18FF3B30))
                        .padding(horizontal = 8.dp, vertical = 6.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("🎟️", fontSize = 14.sp)
                        Spacer(modifier = Modifier.width(3.dp))
                        Text(
                            "$tickets",
                            color = Color(0xFFFF3F3F),
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Black
                        )
                    }
                    Text(
                        "Golden Pass",
                        color = Color.White.copy(alpha = 0.5f),
                        fontSize = 9.sp
                    )
                }
            }
        }
    }
}

@Composable
fun PromoLuckyCard(onClick: () -> Unit, lastSpin: Long) {
    val remainingCooldown = remember(lastSpin) {
        val now = System.currentTimeMillis()
        val elapsed = now - lastSpin
        (24 * 60 * 60 * 1000L - elapsed).coerceAtLeast(0L)
    }

    val isAvailable = remainingCooldown <= 0L

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 12.dp)
            .shadow(12.dp, RoundedCornerShape(16.dp))
            .clickable { onClick() },
        colors = CardDefaults.cardColors(containerColor = Color(0xFF1E0638)),
        shape = RoundedCornerShape(16.dp)
    ) {
        Row(
            modifier = Modifier
                .background(
                    Brush.horizontalGradient(
                        colors = listOf(Color(0xFF310756), Color(0xFF1E023A))
                    )
                )
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Spinning Wheel Icon visual representation
            Box(
                modifier = Modifier
                    .size(54.dp)
                    .clip(CircleShape)
                    .background(Color(0xFFFFD700))
                    .border(2.dp, Color.White, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val radius = size.minDimension / 2f
                    val center = Offset(size.width / 2f, size.height / 2f)
                    
                    // Draw mini sectors
                    for (i in 0..7) {
                        drawArc(
                            color = if (i % 2 == 0) Color(0xFFFF007F) else Color(0xFF00F5FF),
                            startAngle = i * 45f,
                            sweepAngle = 45f,
                            useCenter = true,
                            size = Size(radius * 2f, radius * 2f),
                            topLeft = Offset(center.x - radius, center.y - radius)
                        )
                    }
                    
                    // Core point
                    drawCircle(color = Color.White, radius = 5.dp.toPx(), center = center)
                }
            }

            Spacer(modifier = Modifier.width(16.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    "DAILY LUCKY SPIN WHEEL",
                    color = Color(0xFFFFD700),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 1.sp
                )
                Text(
                    if (isAvailable) "Claim your free daily spins! Win up to 100 Coins jackpot."
                    else "Ready to spin again shortly! Double check remaining stakes.",
                    color = Color.White.copy(alpha = 0.8f),
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold
                )
                
                if (!isAvailable) {
                    val hours = remainingCooldown / (1000 * 60 * 60)
                    val mins = (remainingCooldown % (1000 * 60 * 60)) / (1000 * 60)
                    Text(
                        "⏰ COOLDOWN TIME: ${hours}h ${mins}m (Click to speed reset/test)",
                        color = Color(0xFFFF007F),
                        fontSize = 10.sp,
                        fontWeight = FontWeight.ExtraBold,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }
            }

            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .background(if (isAvailable) Color(0xFF00FF87) else Color(0x33FFFFFF))
                    .padding(horizontal = 12.dp, vertical = 6.dp)
            ) {
                Text(
                    if (isAvailable) "SPIN!" else "LOCKED",
                    color = Color.Black,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Black
                )
            }
        }
    }
}

@Composable
fun CategoryTabBar(activeTab: Int, onTabSelected: (Int) -> Unit) {
    val tabs = listOf("🎯 Arcade", "🛡️ History", "🏆 Leaderboards", "🤝 Refer")
    
    ScrollableTabRow(
        selectedTabIndex = activeTab,
        containerColor = Color.Transparent,
        contentColor = Color.White,
        edgePadding = 16.dp,
        divider = {},
        indicator = {}
    ) {
        tabs.forEachIndexed { idx, label ->
            val isActive = activeTab == idx
            Box(
                modifier = Modifier
                    .padding(end = 8.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(if (isActive) Color(0xFF00F5FF) else Color(0x11FFFFFF))
                    .clickable { onTabSelected(idx) }
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                Text(
                    label,
                    color = if (isActive) Color.Black else Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp
                )
            }
        }
    }
}

// ------------------------------------
// TAB 1: ARCADE GAME LIST PANEL
// ------------------------------------

@Composable
fun TabArcadeGames(
    onStartKnife: (Double) -> Unit,
    onStartShooter: (Double) -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        item {
            Text(
                "POPULAR CASUAL GAMES",
                color = Color.White.copy(alpha = 0.5f),
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 2.sp
            )
            Spacer(modifier = Modifier.height(12.dp))
        }

        // Game 1 Card
        item {
            GameLauncherCard(
                title = "Laser Target Hit",
                subtitle = "Energy Knife Master",
                description = "Launch energy arrows at the rotating quantum core! Complete all core speed levels and multipliers without collision.",
                gradientColor = listOf(Color(0xFF6C289E), Color(0xFF1E0E35)), // Purple palette
                iconEmoji = "🎯",
                wagers = listOf(10.0, 20.0, 50.0),
                onPlay = onStartKnife
            )
            Spacer(modifier = Modifier.height(16.dp))
        }

        // Game 2 Card
        item {
            GameLauncherCard(
                title = "Cosmic Starfighter",
                subtitle = "Retro Jet Shooter",
                description = "Pilot your defense spacecraft to incinerate incoming meteor waves! Power-up weapons and rack up massive scoring multipliers.",
                gradientColor = listOf(Color(0xFFE040FB), Color(0xFF4A148C)), // Magenta-cyber violet palette
                iconEmoji = "🌌",
                wagers = listOf(10.0, 20.0, 50.0),
                onPlay = onStartShooter
            )
            Spacer(modifier = Modifier.height(24.dp))
        }

        // Daily Quest Log section
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1A152E)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        "📋 ARENA DAILY QUESTS",
                        color = Color(0xFF00FF87),
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Black
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    
                    QuestItem(task = "Play 2 Total Matches", reward = "🪙 +10 Coins", progress = 1f)
                    Divider(color = Color.White.copy(alpha = 0.05f), modifier = Modifier.padding(vertical = 10.dp))
                    QuestItem(task = "Reach Level 2 in Laser Target", reward = "🪙 +30 Coins", progress = 0.40f)
                    Divider(color = Color.White.copy(alpha = 0.05f), modifier = Modifier.padding(vertical = 10.dp))
                    QuestItem(task = "Gain 150 points in Starfighter", reward = "🎟️ 1 Golden Pass Ticket", progress = 0f)
                }
            }
        }
    }
}

@Composable
fun GameLauncherCard(
    title: String,
    subtitle: String,
    description: String,
    gradientColor: List<Color>,
    iconEmoji: String,
    wagers: List<Double>,
    onPlay: (Double) -> Unit
) {
    var selectedWager by remember { mutableDoubleStateOf(wagers[0]) }

    Card(
        shape = RoundedCornerShape(20.dp),
        modifier = Modifier
            .fillMaxWidth()
            .shadow(8.dp, RoundedCornerShape(20.dp)),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent)
    ) {
        Column(
            modifier = Modifier
                .background(Brush.horizontalGradient(gradientColor))
                .padding(16.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        subtitle.uppercase(),
                        color = Color(0xFF00FF87),
                        fontSize = 10.sp,
                        fontWeight = FontWeight.ExtraBold,
                        letterSpacing = 1.sp
                    )
                    Text(
                        title,
                        color = Color.White,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Black
                    )
                }
                
                Box(
                    modifier = Modifier
                        .size(42.dp)
                        .clip(CircleShape)
                        .background(Color.White.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(iconEmoji, fontSize = 22.sp)
                }
            }

            Spacer(modifier = Modifier.height(10.dp))
            Text(
                description,
                color = Color.White.copy(alpha = 0.8f),
                fontSize = 12.sp,
                lineHeight = 16.sp
            )

            Spacer(modifier = Modifier.height(16.dp))
            HorizontalDivider(color = Color.White.copy(alpha = 0.12f))
            Spacer(modifier = Modifier.height(12.dp))

            // Choose Stakes selectors
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        "SELECT ENTRY FEE:",
                        color = Color.White.copy(alpha = 0.6f),
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 0.5.sp
                    )
                    Row(modifier = Modifier.padding(top = 4.dp)) {
                        wagers.forEach { fee ->
                            val isSelected = selectedWager == fee
                            Box(
                                modifier = Modifier
                                    .padding(end = 6.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (isSelected) Color(0xFFFFD700) else Color(0x22FFFFFF))
                                    .clickable { selectedWager = fee }
                                    .padding(horizontal = 10.dp, vertical = 6.dp)
                            ) {
                                Text(
                                    "🪙 ${fee.toInt()}",
                                    color = if (isSelected) Color.Black else Color.White,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Black
                                )
                            }
                        }
                    }
                }

                // Play Button
                Button(
                    onClick = { onPlay(selectedWager) },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00FF87)),
                    shape = RoundedCornerShape(12.dp),
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            "CHALLENGE",
                            color = Color.Black,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 13.sp
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Icon(Icons.Filled.ArrowForward, contentDescription = null, tint = Color.Black, modifier = Modifier.size(14.dp))
                    }
                }
            }
        }
    }
}

@Composable
fun QuestItem(task: String, reward: String, progress: Float) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(task, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(4.dp))
            Box(
                modifier = Modifier
                    .fillMaxWidth(0.95f)
                    .height(4.dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(Color.White.copy(alpha = 0.1f))
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxHeight()
                        .fillMaxWidth(progress)
                        .background(Color(0xFF00FF87))
                )
            }
        }
        
        Badge(containerColor = Color(0xFF2C1047)) {
            Text(reward, color = Color(0xFFFFD700), fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(4.dp))
        }
    }
}

// ------------------------------------
// TAB 2: HISTORY LIST PANEL
// ------------------------------------

@Composable
fun TabHistoryList(matches: List<GameMatchEntity>) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text(
            "COMPLETED TOURNAMENT WAGERS",
            color = Color.White.copy(alpha = 0.5f),
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 2.sp
        )
        Spacer(modifier = Modifier.height(12.dp))

        if (matches.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("🛡️", fontSize = 48.sp)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        "No matches completed yet",
                        color = Color.White.copy(alpha = 0.5f),
                        fontSize = 14.sp
                    )
                    Text(
                        "Start your first game to record stakes and scores!",
                        color = Color.White.copy(alpha = 0.35f),
                        fontSize = 11.sp,
                        textAlign = TextAlign.Center
                    )
                }
            }
        } else {
            LazyColumn(modifier = Modifier.fillMaxSize()) {
                items(matches) { match ->
                    TournamentRow(match)
                    Spacer(modifier = Modifier.height(8.dp))
                }
            }
        }
    }
}

@Composable
fun TournamentRow(match: GameMatchEntity) {
    val dateString = remember(match.timestamp) {
        val format = SimpleDateFormat("MMM dd, hh:mm a", Locale.getDefault())
        format.format(Date(match.timestamp))
    }

    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF130F24)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(
                            if (match.gameName.contains("Target")) Color(0xFF512DA8) else Color(0xFFC2185B)
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        if (match.gameName.contains("Target")) "🎯" else "🌌",
                        fontSize = 16.sp
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(match.gameName, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Text(dateString, color = Color.White.copy(alpha = 0.4f), fontSize = 10.sp)
                }
            }

            Column(horizontalAlignment = Alignment.End) {
                Text(
                    "Score: ${match.score}",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp
                )
                Text(
                    if (match.prizeWon > 0) "🪙 +${String.format("%.1f", match.prizeWon)}" else "🪙 -${match.entryFee.toInt()}",
                    color = if (match.prizeWon > 0) Color(0xFF00FF87) else Color(0xFFFF3F3F),
                    fontWeight = FontWeight.Black,
                    fontSize = 13.sp
                )
                Text(
                    "Fee: 🪙 ${match.entryFee.toInt()}",
                    color = Color.White.copy(alpha = 0.4f),
                    fontSize = 9.sp
                )
            }
        }
    }
}

// ------------------------------------
// TAB 3: LEADERBOARDS PODIUM PANEL
// ------------------------------------

@Composable
fun TabLeaderboards(
    leaderboard: List<com.example.data.LeaderboardEntity>,
    selectedGame: String,
    onGameSelected: (String) -> Unit,
    userState: com.example.data.UserUiState
) {
    var currentFilter by remember { mutableStateOf("Global") } // "Global" or "Friends"

    // Construct mock friends data dynamically reflecting the current game and live user info
    val friendsList = remember(selectedGame, userState) {
        val baseFriends = if (selectedGame == "Cosmic Starfighter") {
            listOf(
                com.example.data.LeaderboardEntity(gameName = selectedGame, playerName = "Helix_Striker", score = 395, avatarIndex = 3, isUser = false),
                com.example.data.LeaderboardEntity(gameName = selectedGame, playerName = "SlayerPro_Sarah", score = 320, avatarIndex = 4, isUser = false),
                com.example.data.LeaderboardEntity(gameName = selectedGame, playerName = userState.name, score = 260, avatarIndex = userState.avatarIndex, isUser = true),
                com.example.data.LeaderboardEntity(gameName = selectedGame, playerName = "Noob_Buster", score = 115, avatarIndex = 2, isUser = false),
                com.example.data.LeaderboardEntity(gameName = selectedGame, playerName = "CollegeCaboose", score = 50, avatarIndex = 3, isUser = false)
            )
        } else {
            listOf(
                com.example.data.LeaderboardEntity(gameName = selectedGame, playerName = "SquadCaptain_Rohan", score = 310, avatarIndex = 2, isUser = false),
                com.example.data.LeaderboardEntity(gameName = selectedGame, playerName = "SlayerPro_Sarah", score = 240, avatarIndex = 4, isUser = false),
                com.example.data.LeaderboardEntity(gameName = selectedGame, playerName = userState.name, score = 190, avatarIndex = userState.avatarIndex, isUser = true),
                com.example.data.LeaderboardEntity(gameName = selectedGame, playerName = "CollegeCaboose", score = 160, avatarIndex = 3, isUser = false),
                com.example.data.LeaderboardEntity(gameName = selectedGame, playerName = "GamerChic_9", score = 95, avatarIndex = 1, isUser = false),
                com.example.data.LeaderboardEntity(gameName = selectedGame, playerName = "Noob_Buster", score = 45, avatarIndex = 2, isUser = false)
            )
        }
        // Auto sort with computed rankings
        baseFriends.sortedByDescending { it.score }.mapIndexed { index, entity ->
            entity.copy(rank = index + 1)
        }
    }

    val activeLeaderboard = if (currentFilter == "Global") leaderboard else friendsList

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        // 1. Selector Pill Rows
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            val games = listOf("Laser Target Hit", "Cosmic Starfighter")
            games.forEach { game ->
                val isSelected = selectedGame == game
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .padding(horizontal = 4.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(if (isSelected) Color(0xFF9C27B0) else Color(0x11FFFFFF))
                        .clickable { onGameSelected(game) }
                        .padding(vertical = 10.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        game,
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // 2. High-Fidelity Custom Filter Toggle (Segmented Control style)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp)
                .clip(RoundedCornerShape(50))
                .background(Color(0x0FFFFFFF))
                .padding(4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            val filters = listOf("Global Arena 🌍", "My Squad 👥")
            filters.forEach { filter ->
                val isSelected = (filter.startsWith("Global") && currentFilter == "Global") ||
                        (filter.startsWith("My Squad") && currentFilter == "Friends")
                
                val toggleModifier = if (isSelected) {
                    Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(50))
                        .background(Brush.horizontalGradient(listOf(Color(0xFF9C27B0), Color(0xFF673AB7))))
                } else {
                    Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(50))
                        .background(Color.Transparent)
                }

                Box(
                    modifier = toggleModifier
                        .clickable {
                            currentFilter = if (filter.startsWith("Global")) "Global" else "Friends"
                        }
                        .padding(vertical = 8.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = filter,
                        color = if (isSelected) Color.White else Color.White.copy(alpha = 0.6f),
                        fontWeight = if (isSelected) FontWeight.Black else FontWeight.Bold,
                        fontSize = 12.sp
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Get Top 3 and remainder
        val top3 = activeLeaderboard.take(3)
        val remainder = activeLeaderboard.drop(3)

        if (activeLeaderboard.isNotEmpty()) {
            // Render podium hierarchy
            PodiumView(top3 = top3)
            Spacer(modifier = Modifier.height(16.dp))
        }

        val rankingHeaderLabel = if (currentFilter == "Global") "ARENA RANKINGS" else "FRIENDS STANDINGS"
        Text(
            rankingHeaderLabel,
            color = Color.White.copy(alpha = 0.5f),
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 2.sp
        )
        Spacer(modifier = Modifier.height(8.dp))

        if (activeLeaderboard.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Text("Loading Leaderboards...", color = Color.White.copy(alpha = 0.4f))
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .weight(1f)
            ) {
                items(remainder) { ranking ->
                    LeaderRow(ranking)
                    Spacer(modifier = Modifier.height(6.dp))
                }
            }
        }
    }
}

@Composable
fun PodiumView(top3: List<com.example.data.LeaderboardEntity>) {
    // We order top 3 as: 2nd (left), 1st (center), 3rd (right)
    val second = top3.getOrNull(1)
    val first = top3.getOrNull(0)
    val third = top3.getOrNull(2)

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(160.dp),
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.Bottom
    ) {
        // 2nd Place Card (left)
        if (second != null) {
            PodiumCol(item = second, height = 125.dp, medal = "🥈", medalColor = Color(0xFFC0C0C0))
        } else {
            Spacer(modifier = Modifier.weight(1f))
        }

        // 1st Place Card (middle - taller!)
        if (first != null) {
            PodiumCol(item = first, height = 155.dp, medal = "🥇", medalColor = Color(0xFFFFD700))
        }

        // 3rd Place Card (right)
        if (third != null) {
            PodiumCol(item = third, height = 110.dp, medal = "🥉", medalColor = Color(0xFFCD7F32))
        } else {
            Spacer(modifier = Modifier.weight(1f))
        }
    }
}

@Composable
fun RowScope.PodiumCol(
    item: com.example.data.LeaderboardEntity,
    height: androidx.compose.ui.unit.Dp,
    medal: String,
    medalColor: Color
) {
    Card(
        modifier = Modifier
            .weight(1f)
            .height(height)
            .padding(horizontal = 4.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (item.isUser) Color(0xFF2C1047) else Color(0xFF130D29)
        ),
        shape = RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(8.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Bottom
        ) {
            // Player Emoji Badge
            PlayerAvatarView(
                avatarIndex = item.avatarIndex,
                size = 36.dp,
                modifier = Modifier.border(1.dp, medalColor, CircleShape)
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                item.playerName,
                color = if (item.isUser) Color(0xFF00FF87) else Color.White,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center,
                maxLines = 1
            )
            Text(
                "${item.score} pts",
                color = Color(0xFFFFD700),
                fontSize = 11.sp,
                fontWeight = FontWeight.Black
            )
            Spacer(modifier = Modifier.height(6.dp))
            
            // Draw numerical rank label
            Box(
                modifier = Modifier
                    .size(24.dp)
                    .clip(CircleShape)
                    .background(medalColor),
                contentAlignment = Alignment.Center
            ) {
                Text(medal, fontSize = 12.sp)
            }
        }
    }
}

@Composable
fun LeaderRow(ranking: com.example.data.LeaderboardEntity) {
    Card(
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (ranking.isUser) Color(0xFF291040) else Color(0xFF100B1A)
        ),
        modifier = Modifier
            .fillMaxWidth()
            .border(
                if (ranking.isUser) 1.dp else 0.dp,
                if (ranking.isUser) Color(0xFF00FF87) else Color.Transparent,
                RoundedCornerShape(10.dp)
            )
    ) {
        Row(
            modifier = Modifier.padding(10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                // Rank label
                Text(
                    "#${ranking.rank}",
                    color = Color.White.copy(alpha = 0.5f),
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 12.sp,
                    modifier = Modifier.width(32.dp)
                )

                PlayerAvatarView(
                    avatarIndex = ranking.avatarIndex,
                    size = 30.dp
                )

                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    ranking.playerName,
                    color = if (ranking.isUser) Color(0xFF00FF87) else Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp
                )
            }

            Text(
                "${ranking.score} pts",
                color = Color(0xFFFFD700),
                fontWeight = FontWeight.Black,
                fontSize = 12.sp
            )
        }
    }
}

// ------------------------------------
// TAB 4: REFER & EARN PANEL
// ------------------------------------

@Composable
fun TabReferAndEarn() {
    val context = LocalContext.current
    val referralCode = "WINPLAY_GUEST88"

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(modifier = Modifier.height(16.dp))
        Text(
            "🤝 SHARE & MULTIPLY",
            color = Color(0xFF00FF87),
            fontSize = 13.sp,
            fontWeight = FontWeight.Black,
            letterSpacing = 2.sp
        )
        Text(
            "REFER YOUR SQUAD TO WIN DOUBLE BONUS COINS",
            color = Color.White,
            fontSize = 16.sp,
            fontWeight = FontWeight.Black,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(vertical = 4.dp)
        )
        Text(
            "Send your promo key link to a crew member. Gain 🪙 50 Coins and 🎟️ 2 Free Golden Passes instantly on their deposit first!",
            color = Color.White.copy(alpha = 0.6f),
            fontSize = 12.sp,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(horizontal = 16.dp)
        )

        Spacer(modifier = Modifier.height(24.dp))

        // Large Code Container
        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1B0731)),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
                .fillMaxWidth(0.9f)
                .shadow(12.dp)
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    "YOUR CODE KEY",
                    color = Color.White.copy(alpha = 0.5f),
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    referralCode,
                    color = Color(0xFFFFD700),
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 1.5.sp
                )
                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = {
                        val shareIntent = Intent().apply {
                            action = Intent.ACTION_SEND
                            putExtra(
                                Intent.EXTRA_TEXT,
                                "Hey! Join me on WinPlay Arena gaming app! Enter my promo key code $referralCode on signup to secure FREE 100 game coins instantly! Download development APK link: https://ai.studio/build"
                            )
                            type = "text/plain"
                        }
                        context.startActivity(Intent.createChooser(shareIntent, "Share Referral Link"))
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00F5FF)),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.Share, contentDescription = null, tint = Color.Black, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("INVITE SQUAD", color = Color.Black, fontWeight = FontWeight.Black)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Refer progress milestones card
        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0x13FFFFFF)),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier.padding(14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text("Squad invites pending:", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Text("Milestone: 3 references (0/3)", color = Color.White.copy(alpha = 0.5f), fontSize = 11.sp)
                }
                Badge(containerColor = Color(0xFF532488)) {
                    Text("🪙 +150 Coins bonus", color = Color(0xFFFFD700), modifier = Modifier.padding(4.dp), fontSize = 11.sp)
                }
            }
        }
    }
}

// ------------------------------------
// OVERLAYS & MODAL DIALOGS
// ------------------------------------

@Composable
fun PlayerAvatarView(
    avatarIndex: Int,
    size: androidx.compose.ui.unit.Dp,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .size(size)
            .clip(CircleShape)
            .background(getAvatarBrush(avatarIndex)),
        contentAlignment = Alignment.Center
    ) {
        if (avatarIndex < 1000) {
            Text(
                text = getAvatarEmoji(avatarIndex),
                fontSize = (size.value * 0.52f).sp
            )
        } else {
            // Decode customizer values
            val accessoryIdx = avatarIndex % 10
            val eyesIdx = (avatarIndex / 10) % 10
            val hairIdx = (avatarIndex / 100) % 10
            val baseIdx = (avatarIndex / 1000) % 10
            
            val bases = listOf("🤖", "👽", "🦊", "🐱", "🐼", "🐵")
            val hairs = listOf("", "👑", "🧢", "🎧", "🎩", "🎀", "🤠")
            val eyes = listOf("", "😎", "👁️", "🤓", "🎭", "🛡️")
            val accessories = listOf("", "⚔️", "🛡️", "🔥", "🎒", "🦋")

            // Back Accessory Layer
            val acc = accessories.getOrNull(accessoryIdx) ?: ""
            if (acc.isNotEmpty()) {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = if (acc in listOf("🦋", "🔥", "⚔️")) Alignment.Center else Alignment.BottomCenter
                ) {
                    Text(
                        text = acc,
                        fontSize = (size.value * 0.5f).sp,
                        modifier = Modifier.graphicsLayer { alpha = 0.8f }
                    )
                }
            }

            // Head Base Layer
            val baseEmoji = bases.getOrNull(baseIdx) ?: "🤖"
            Text(
                text = baseEmoji,
                fontSize = (size.value * 0.5f).sp,
                modifier = Modifier.align(Alignment.Center)
            )

            // Eyewear Layer
            val eyesEmoji = eyes.getOrNull(eyesIdx) ?: ""
            if (eyesEmoji.isNotEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .offset(y = (-size.value * 0.02f).dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = eyesEmoji,
                        fontSize = (size.value * 0.35f).sp
                    )
                }
            }

            // Hair/Headgear Layer
            val hairEmoji = hairs.getOrNull(hairIdx) ?: ""
            if (hairEmoji.isNotEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .offset(y = (-size.value * 0.22f).dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = hairEmoji,
                        fontSize = (size.value * 0.36f).sp
                    )
                }
            }
        }
    }
}

@Composable
fun CustomizerRow(
    title: String,
    options: List<String>,
    selectedIndex: Int,
    tagPrefix: String,
    onSelect: (Int) -> Unit
) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Text(
            text = title,
            color = Color.White.copy(alpha = 0.7f),
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(top = 10.dp)
        )
        Spacer(modifier = Modifier.height(4.dp))
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            options.forEachIndexed { idx, opt ->
                val isSelected = selectedIndex == idx
                val labelText = if (opt.startsWith("❌")) "None" else opt
                val bgModifier = if (isSelected) {
                    Modifier.background(Brush.horizontalGradient(listOf(Color(0xFF00FF87), Color(0xFF00B0FF))))
                } else {
                    Modifier.background(Color(0x1AFFFFFF))
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .then(bgModifier)
                        .clickable { onSelect(idx) }
                        .padding(horizontal = 14.dp, vertical = 8.dp)
                        .testTag("${tagPrefix}_option_${idx}"),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = labelText,
                        color = if (isSelected) Color.Black else Color.White,
                        fontWeight = if (isSelected) FontWeight.Black else FontWeight.Normal,
                        fontSize = 11.sp
                    )
                }
            }
        }
    }
}

@Composable
fun EditProfileDialog(
    currentName: String,
    currentAvatar: Int,
    totalGames: Int,
    onDismiss: () -> Unit,
    onSave: (String, Int) -> Unit
) {
    var textName by remember { mutableStateOf(currentName) }
    
    // Choose Creator Mode vs Classic mode
    var isCustomizerMode by remember { mutableStateOf(currentAvatar >= 1000) }

    // Customizer Parts State
    var customBase by remember { mutableIntStateOf(if (currentAvatar >= 1000) (currentAvatar / 1000) % 10 else 0) }
    var customHair by remember { mutableIntStateOf(if (currentAvatar >= 1000) (currentAvatar / 100) % 10 else 0) }
    var customEyes by remember { mutableIntStateOf(if (currentAvatar >= 1000) (currentAvatar / 10) % 10 else 0) }
    var customAccessory by remember { mutableIntStateOf(if (currentAvatar >= 1000) currentAvatar % 10 else 0) }

    // Classic Emoji selection State (1..4)
    var selectedClassicAvatar by remember { mutableIntStateOf(if (currentAvatar < 1000) currentAvatar else 1) }

    val activeAvatarIndex = if (isCustomizerMode) {
        1000 * customBase + 100 * customHair + 10 * customEyes + customAccessory
    } else {
        selectedClassicAvatar
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = "Elite Gaming Profile Creator", 
                color = Color.White, 
                fontWeight = FontWeight.Black,
                fontSize = 18.sp
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
            ) {
                // LIVE PROFILE PREVIEW CARD
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(Color(0xFF0F091A))
                        .border(1.dp, Color(0xFF00F5FF).copy(alpha = 0.3f), RoundedCornerShape(16.dp))
                        .padding(16.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        PlayerAvatarView(
                            avatarIndex = activeAvatarIndex,
                            size = 80.dp,
                            modifier = Modifier
                                .shadow(8.dp, CircleShape)
                                .border(3.dp, Color(0xFFFFD700), CircleShape)
                                .testTag("customizer_avatar_preview")
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = textName.ifBlank { "Pro Gamer" },
                            color = Color.White,
                            fontWeight = FontWeight.Black,
                            fontSize = 15.sp,
                            textAlign = TextAlign.Center
                        )
                        Text(
                            text = "PREVIEW AVATAR",
                            color = Color(0xFF00FF87),
                            fontWeight = FontWeight.Bold,
                            fontSize = 9.sp,
                            letterSpacing = 1.2.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // PROGRESSION TRACKER CARD (based on total games played)
                val calculatedLevel = (totalGames / 3) + 1
                val gamesInLevel = totalGames % 3
                val nextLevelTarget = 3
                val progressFraction = gamesInLevel.toFloat() / nextLevelTarget.toFloat()

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("dialog_progression_card"),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF19102A)),
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, Color(0xFF00FF87).copy(alpha = 0.3f))
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                "🏆 PROGRESSION RANK",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp,
                                letterSpacing = 1.sp
                            )
                            Text(
                                "Level $calculatedLevel",
                                color = Color(0xFF00FF87),
                                fontWeight = FontWeight.Black,
                                fontSize = 13.sp,
                                modifier = Modifier.testTag("dialog_progression_level")
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        // Progress Bar Container
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(8.dp)
                                .clip(RoundedCornerShape(4.dp))
                                .background(Color.White.copy(alpha = 0.1f))
                                .testTag("dialog_progression_bar_container")
                        ) {
                            Box(
                                modifier = Modifier
                                    .fillMaxHeight()
                                    .fillMaxWidth(fraction = progressFraction.coerceIn(0.01f, 1.0f))
                                    .background(Brush.horizontalGradient(listOf(Color(0xFF00FF87), Color(0xFF2196F3))))
                                    .testTag("dialog_progression_bar_progress")
                            )
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                "Total Games Played: $totalGames",
                                color = Color.White.copy(alpha = 0.7f),
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Medium,
                                modifier = Modifier.testTag("dialog_progression_total_games")
                            )
                            Text(
                                "$gamesInLevel / $nextLevelTarget games played for Level ${calculatedLevel + 1}",
                                color = Color(0xFFFF007F),
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.testTag("dialog_progression_needed")
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // ENTER GAMERTAG FIELD
                OutlinedTextField(
                    value = textName,
                    onValueChange = { textName = it },
                    label = { Text("Enter Gamertag") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedLabelColor = Color(0xFF00F5FF),
                        unfocusedLabelColor = Color.White.copy(alpha = 0.5f),
                        focusedContainerColor = Color(0x0FFFFFFF),
                        unfocusedContainerColor = Color(0x05FFFFFF)
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("gamertag_textfield")
                )

                Spacer(modifier = Modifier.height(16.dp))

                // TOGGLE TABS: CUSTOM creator vs CLASSIC selection
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(50))
                        .background(Color(0x15FFFFFF))
                        .padding(4.dp)
                ) {
                    // Custom Creator Button
                    val customSelectedModifier = if (isCustomizerMode) {
                        Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(50))
                            .background(Brush.horizontalGradient(listOf(Color(0xFF9C27B0), Color(0xFF673AB7))))
                    } else {
                        Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(50))
                            .background(Color.Transparent)
                    }
                    Box(
                        modifier = customSelectedModifier
                            .clickable { isCustomizerMode = true }
                            .padding(vertical = 8.dp)
                            .testTag("tab_custom_creator"),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "CREATOR 🛠️",
                            color = if (isCustomizerMode) Color.White else Color.White.copy(alpha = 0.6f),
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp
                        )
                    }

                    // Classic Button
                    val classicSelectedModifier = if (!isCustomizerMode) {
                        Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(50))
                            .background(Brush.horizontalGradient(listOf(Color(0xFF9C27B0), Color(0xFF673AB7))))
                    } else {
                        Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(50))
                            .background(Color.Transparent)
                    }
                    Box(
                        modifier = classicSelectedModifier
                            .clickable { isCustomizerMode = false }
                            .padding(vertical = 8.dp)
                            .testTag("tab_classic_avatar"),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "CLASSIC 🐺",
                            color = if (!isCustomizerMode) Color.White else Color.White.copy(alpha = 0.6f),
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                if (isCustomizerMode) {
                    // CUSTOM INTERFACE: 4 SWIPE TRACKS
                    val baseOptions = listOf("🤖 Mech", "👽 Alien", "🦊 Fox", "🐱 Kitty", "🐼 Panda", "🐵 Ape")
                    val hairOptions = listOf("❌ None", "👑 Crown", "🧢 Cap", "🎧 Headset", "🎩 Tophat", "🎀 Ribbon", "🤠 Cowboy")
                    val eyesOptions = listOf("❌ None", "😎 Glasses", "👁️ Laser", "🤓 Nerd", "🎭 Mask", "🛡️ Visor")
                    val accessoryOptions = listOf("❌ None", "⚔️ Swords", "🛡️ Shield", "🔥 Aura", "🎒 Pack", "🦋 Wings")

                    CustomizerRow(
                        title = "1. HERO CHARACTER",
                        options = baseOptions,
                        selectedIndex = customBase,
                        tagPrefix = "hero",
                        onSelect = { customBase = it }
                    )

                    CustomizerRow(
                        title = "2. HEADGEAR / HAIR",
                        options = hairOptions,
                        selectedIndex = customHair,
                        tagPrefix = "hair",
                        onSelect = { customHair = it }
                    )

                    CustomizerRow(
                        title = "3. EYEWEAR / EYE EXPRESSION",
                        options = eyesOptions,
                        selectedIndex = customEyes,
                        tagPrefix = "eyewear",
                        onSelect = { customEyes = it }
                    )

                    CustomizerRow(
                        title = "4. WEAPONS / BACK ACCESSORY",
                        options = accessoryOptions,
                        selectedIndex = customAccessory,
                        tagPrefix = "accessory",
                        onSelect = { customAccessory = it }
                    )

                } else {
                    // CLASSIC INTERFACE: PICK FROM 4 DEFAULTS
                    Text(
                        text = "CHOOSE CLASSIC EMOJI",
                        color = Color.White.copy(alpha = 0.7f),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(vertical = 8.dp)
                    )
                    Row(
                        horizontalArrangement = Arrangement.SpaceEvenly,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp)
                    ) {
                        for (i in 1..4) {
                            val isSelected = selectedClassicAvatar == i
                            Box(
                                modifier = Modifier
                                    .size(54.dp)
                                    .clip(CircleShape)
                                    .background(getAvatarBrush(i))
                                    .border(
                                        if (isSelected) 3.dp else 0.dp,
                                        if (isSelected) Color(0xFF00FF87) else Color.Transparent,
                                        CircleShape
                                    )
                                    .clickable { selectedClassicAvatar = i }
                                    .testTag("classic_avatar_option_${i}"),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(getAvatarEmoji(i), fontSize = 26.sp)
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { onSave(textName, activeAvatarIndex) },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00FF87)),
                modifier = Modifier.testTag("save_profile_button")
            ) {
                Text("SAVE PROFILE 💾", color = Color.Black, fontWeight = FontWeight.Black, fontSize = 11.sp)
            }
        },
        dismissButton = {
            TextButton(
                onClick = onDismiss,
                modifier = Modifier.testTag("cancel_profile_button")
            ) {
                Text("CANCEL", color = Color.White.copy(alpha = 0.6f), fontWeight = FontWeight.Bold, fontSize = 11.sp)
            }
        },
        containerColor = Color(0xFF1E1430)
    )
}

@Composable
fun AddCoinsDialog(
    onDismiss: () -> Unit,
    onAdd: (Double, Boolean) -> Unit
) {
    var coinsInputText by remember { mutableStateOf("100") }
    var isPromoApplied by remember { mutableStateOf(true) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text("Add Virtual Game Coins", color = Color.White, fontWeight = FontWeight.Black)
        },
        text = {
            Column {
                Text("Replenish your coins to join stakes and tournament matches. Winnings accrue real cash equivalents sync!", color = Color.White.copy(alpha = 0.8f), fontSize = 12.sp)
                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = coinsInputText,
                    onValueChange = { coinsInputText = it },
                    label = { Text("Coin Amount") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedLabelColor = Color(0xFFFFD700)
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Promo Coupon Checklist
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.clickable { isPromoApplied = !isPromoApplied }
                ) {
                    Checkbox(
                        checked = isPromoApplied,
                        onCheckedChange = { isPromoApplied = it },
                        colors = CheckboxDefaults.colors(checkedColor = Color(0xFF00FF87))
                    )
                    Column(modifier = Modifier.padding(start = 4.dp)) {
                        Text("Apply Code: COONGAMEPASS", color = Color(0xFF00FF87), fontSize = 11.sp, fontWeight = FontWeight.Black)
                        Text("Awards +1 Golden ticket and removes transaction limits!", color = Color.White.copy(alpha = 0.5f), fontSize = 10.sp)
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val doubleValue = coinsInputText.toDoubleOrNull() ?: 100.0
                    onAdd(doubleValue, isPromoApplied)
                },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFFD700))
            ) {
                Text("ADD COINS", color = Color.Black, fontWeight = FontWeight.Black)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("CANCEL", color = Color.White.copy(alpha = 0.6f))
            }
        },
        containerColor = Color(0xFF160E27)
    )
}

// --- SPIN PARTICLE FOR ANIMATED BURST ---
data class SpinParticle(
    val id: Int,
    val x: Float,
    val y: Float,
    val size: Float,
    val color: Color,
    val angle: Float,
    val speed: Float,
    val emoji: String = "✨"
)

@Composable
fun LuckyWheelModal(
    lastSpinTime: Long,
    onDismiss: () -> Unit,
    onClaimReward: (String, Double, Int) -> Unit,
    onQuickReset: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    // Rotation angle state for spin-the-wheel
    val rotationAngle = remember { Animatable(0f) }
    var isSpinning by remember { mutableStateOf(false) }
    var winningSectorIndex by remember { mutableIntStateOf(-1) }
    var hasClaimedBonus by remember { mutableStateOf(false) }
    var particles by remember { mutableStateOf<List<SpinParticle>>(emptyList()) }

    val remainingCooldown = remember(lastSpinTime, hasClaimedBonus) {
        val now = System.currentTimeMillis()
        val elapsed = now - lastSpinTime
        (24 * 60 * 60 * 1000L - elapsed).coerceAtLeast(0L)
    }

    val isEligible = remainingCooldown <= 0L

    val sectors = listOf(
        "10 Coins",
        "Better Luck!",
        "1 Ticket Pass",
        "50 Coins Mega",
        "15 Coins",
        "2 Ticket Bonus",
        "100 Jackpot",
        "5 Coins Boost"
    )

    val sectorLabels = listOf(
        "🪙 10c",
        "😢 No Win",
        "🎟️ 1 Tkt",
        "🪙 50 MEGA",
        "🪙 15c",
        "🎟️ 2 Tkts",
        "💎 100 JKPT",
        "🪙 5 BOOST"
    )

    val sectorColors = listOf(
        Color(0xFF6A1B9A), // 10 Coins - Purple
        Color(0xFF263238), // Better Luck - Dark Slate
        Color(0xFFD81B60), // 1 Ticket - Deep Pink
        Color(0xFF1E88E5), // 50 Coins - Sky Blue
        Color(0xFF00897B), // 15 Coins - Teal
        Color(0xFFE91E63), // 2 Tickets - Bright Pink
        Color(0xFFFF5722), // 100 Jackpot - Fire Orange
        Color(0xFF43A047)  // 5 Coins - Green
    )

    // Needle bounce physics calculation based on sector boundaries
    val sectorDegrees = 45f
    val sectorChange = (rotationAngle.value + 22.5f) / sectorDegrees
    val integerPart = sectorChange.toInt()
    val fractionalPart = sectorChange - integerPart
    val needleRotation = if (isSpinning && fractionalPart < 0.25f) {
        // Dip or bounce the needle when crossing sector borders
        -18f * (1f - fractionalPart / 0.25f)
    } else {
        0f
    }

    // Launch burst particle effects when landing
    LaunchedEffect(isSpinning) {
        if (!isSpinning && winningSectorIndex != -1) {
            val emojiList = listOf("✨", "🪙", "🎉", "🔥", "👑", "🎟️")
            val colors = listOf(Color(0xFFFFD700), Color(0xFF00FF87), Color(0xFF00F5FF), Color(0xFFFF007F))
            particles = List(35) { i ->
                val angleRad = (i * (360f / 35f)) * PI.toFloat() / 180f
                val speed = (4..16).random().toFloat()
                SpinParticle(
                    id = i,
                    x = 0f,
                    y = 0f,
                    size = (14..24).random().toFloat(),
                    color = colors.random(),
                    angle = angleRad,
                    speed = speed,
                    emoji = emojiList.random()
                )
            }

            // Animate particles outward
            for (step in 1..35) {
                delay(20)
                particles = particles.map { p ->
                    p.copy(
                        x = p.x + (p.speed * cos(p.angle)),
                        y = p.y + (p.speed * sin(p.angle)) - 0.8f, // custom draft
                        speed = p.speed * 0.94f
                    )
                }
            }
            particles = emptyList() // clear
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xF00A0618))
            .padding(16.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.verticalScroll(rememberScrollState())
        ) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    "🍀 LUCKY DROP WHEEL",
                    color = Color.White,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )

                IconButton(onClick = onDismiss) {
                    Text("✕", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                }
            }

            Text(
                "Spin once every 24 hours to secure extra gaming tokens absolutely free!",
                color = Color.White.copy(alpha = 0.6f),
                fontSize = 12.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(horizontal = 24.dp)
            )

            Spacer(modifier = Modifier.height(24.dp))

            // --- THE PHYSICAL SPIN THE WHEEL CANVAS ---
            Box(
                modifier = Modifier.size(280.dp),
                contentAlignment = Alignment.Center
            ) {
                // 1. ROTATING SECTORS & TEXT LABELS
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .rotate(rotationAngle.value),
                    contentAlignment = Alignment.Center
                ) {
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        val w = size.width
                        val r = w / 2f
                        val center = Offset(w / 2f, size.height / 2f)

                        // Draw outer border ring (Gold border)
                        drawCircle(
                            color = Color(0xFFFFD700),
                            radius = r - 10f,
                            center = center,
                            style = Stroke(width = 16f)
                        )

                        // Draw golden rim bulb decorations with dynamic real-time blink!
                        val numDots = 24
                        val blinkPhase = (System.currentTimeMillis() / 250).toInt()
                        for (d in 0 until numDots) {
                            val dotAngle = (d * (360f / numDots) * PI / 180f).toFloat()
                            val dotRadius = r - 10f
                            val isLit = (d + blinkPhase) % 2 == 0
                            drawCircle(
                                color = if (isLit) Color.White else Color(0xFFC79A00),
                                radius = 5f,
                                center = Offset(center.x + dotRadius * cos(dotAngle), center.y + dotRadius * sin(dotAngle))
                            )
                        }

                        // Draw sectors
                        for (i in 0..7) {
                            val angleStart = i * 45f
                            drawArc(
                                color = sectorColors[i],
                                startAngle = angleStart,
                                sweepAngle = 45f,
                                useCenter = true,
                                size = Size(r * 2f - 36f, r * 2f - 36f),
                                topLeft = Offset(18f, 18f)
                            )
                        }

                        // Draw dividing borders
                        for (i in 0..7) {
                            val rad = (i * 45f * PI / 180f).toFloat()
                            drawLine(
                                color = Color(0x7F0A0618),
                                start = center,
                                end = Offset(center.x + (r - 18f) * cos(rad), center.y + (r - 18f) * sin(rad)),
                                strokeWidth = 4f
                            )
                        }
                    }

                    // Draw labels aligned directly in sector middles
                    for (i in 0..7) {
                        val sectorAngle = i * 45f + 22.5f
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .rotate(sectorAngle),
                            contentAlignment = Alignment.TopCenter
                        ) {
                            Text(
                                text = sectorLabels[i],
                                color = Color.White,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Black,
                                modifier = Modifier.padding(top = 32.dp) // Perfect inset of sector text
                            )
                        }
                    }
                }

                // 2. PIN HINGE POINTER WITH ARCADE FLICKER PHYSIC
                Box(
                    modifier = Modifier
                        .align(Alignment.TopCenter)
                        .offset(y = (-14).dp)
                        .graphicsLayer {
                            transformOrigin = TransformOrigin(0.5f, 0f)
                            rotationZ = needleRotation
                        }
                        .size(width = 24.dp, height = 36.dp)
                        .background(
                            Brush.verticalGradient(
                                listOf(Color(0xFFFFFF3F), Color(0xFFFF0D55))
                            ),
                            shape = RoundedCornerShape(topStart = 12.dp, topEnd = 12.dp, bottomStart = 4.dp, bottomEnd = 4.dp)
                        )
                )

                // 3. PULSING ALWAYS ON CENTRAL HUB BUTTON
                val infiniteTransition = rememberInfiniteTransition(label = "pulse")
                val pulseScale by infiniteTransition.animateFloat(
                    initialValue = 1f,
                    targetValue = if (!isSpinning && isEligible && winningSectorIndex == -1) 1.15f else 1f,
                    animationSpec = infiniteRepeatable(
                        animation = tween(1000, easing = FastOutSlowInEasing),
                        repeatMode = RepeatMode.Reverse
                    ),
                    label = "scale"
                )

                Box(
                    modifier = Modifier
                        .size(72.dp)
                        .graphicsLayer {
                            scaleX = pulseScale
                            scaleY = pulseScale
                        }
                        .shadow(8.dp, CircleShape)
                        .clip(CircleShape)
                        .background(
                            Brush.radialGradient(
                                colors = when {
                                    isSpinning -> listOf(Color(0xFFE0E0E0), Color(0xFF757575))
                                    !isEligible && winningSectorIndex == -1 -> listOf(Color(0xFF555555), Color(0xFF222222))
                                    winningSectorIndex != -1 -> listOf(Color(0xFF00FF87), Color(0xFF00A550))
                                    else -> listOf(Color(0xFFFFEA00), Color(0xFFFF9100)) // Gold gradient for active
                                }
                            )
                        )
                        .border(3.dp, Color.White, CircleShape)
                        .clickable(enabled = !isSpinning && isEligible && winningSectorIndex == -1) {
                            hasClaimedBonus = false
                            isSpinning = true
                            
                            val luckyIndex = (0..7).random()
                            winningSectorIndex = luckyIndex
                            
                            // To land on 'luckyIndex' at 12 o'clock, we calculate the angle:
                            // We need a base of 3600f representing 10 spins, then we adjust to center it perfectly.
                            val finalStoppingPoint = 3600f + 247.5f - (luckyIndex * 45f)

                            scope.launch {
                                rotationAngle.snapTo(0f)
                                rotationAngle.animateTo(
                                    targetValue = finalStoppingPoint,
                                    animationSpec = tween(
                                        durationMillis = 3500,
                                        easing = CubicBezierEasing(0.1f, 0.75f, 0.2f, 1.0f)
                                    )
                                )
                                isSpinning = false
                            }
                        },
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = when {
                            isSpinning -> "SPIN..."
                            !isEligible && winningSectorIndex == -1 -> "DONE"
                            winningSectorIndex != -1 -> "WIN!"
                            else -> "SPIN\nGO!"
                        },
                        color = Color.Black,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Black,
                        textAlign = TextAlign.Center,
                        lineHeight = 14.sp
                    )
                }

                // 4. FLOATING EXPLODING PARTICLES OVERLAY
                particles.forEach { p ->
                    Text(
                        text = p.emoji,
                        fontSize = p.size.sp,
                        color = p.color,
                        modifier = Modifier.offset(x = p.x.dp, y = p.y.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Text on sectors helper layout
            Text(
                "Sectors Map: (0) 10c | (1) No Winnings | (2) 1 Ticket | (3) 50c | (4) 15c | (5) 2 Tickets | (6) 100c | (7) 5c",
                color = Color.White.copy(alpha = 0.35f),
                fontSize = 9.sp
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Result display section
            AnimatedVisibility(
                visible = winningSectorIndex != -1 && !isSpinning,
                enter = slideInVertically(initialOffsetY = { 100 }) + fadeIn(),
                exit = shrinkVertically() + fadeOut()
            ) {
                val rewardText = sectors[winningSectorIndex]
                val coinsPrize = when (winningSectorIndex) {
                    0 -> 10.0
                    3 -> 50.0
                    4 -> 15.0
                    6 -> 100.0
                    7 -> 5.0
                    else -> 0.0
                }
                val ticketsPrize = when (winningSectorIndex) {
                    2 -> 1
                    5 -> 2
                    else -> 0
                }

                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1C38)),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth(0.9f)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            "🎉 SPIN OUTCOME 🎉",
                            color = Color(0xFFFFD700),
                            fontWeight = FontWeight.Black,
                            fontSize = 13.sp
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            "REWARD: $rewardText",
                            color = Color.White,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                        Spacer(modifier = Modifier.height(12.dp))

                        if (!hasClaimedBonus) {
                            Button(
                                onClick = {
                                    onClaimReward(rewardText, coinsPrize, ticketsPrize)
                                    hasClaimedBonus = true
                                    winningSectorIndex = -1
                                    Toast.makeText(context, "Claimed successfully into wallet logs!", Toast.LENGTH_SHORT).show()
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00FF87)),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text("CLAIM TO WALLET", color = Color.Black, fontWeight = FontWeight.Bold)
                            }
                        } else {
                            Text(
                                "Claimed! Ready shortly.",
                                color = Color(0xFF00FF87),
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp
                            )
                        }
                    }
                }
            }

            if (!isEligible && winningSectorIndex == -1) {
                Text(
                    "You already spun today! Free spins reset daily.",
                    color = Color.White.copy(alpha = 0.7f),
                    fontSize = 13.sp
                )
                Spacer(modifier = Modifier.height(8.dp))

                // Super awesome override button for easy testing / presentation
                TextButton(
                    onClick = {
                        onQuickReset()
                        Toast.makeText(context, "Spin timer reset! You can spin now.", Toast.LENGTH_SHORT).show()
                    },
                    colors = ButtonDefaults.textButtonColors(contentColor = Color(0xFFFFD700))
                ) {
                    Text("⚡ [DEVELOPER RESET SPIN FOR PRESENTATION] ⚡")
                }
            }
        }
    }
}

// ------------------------------------
// BRUSH / BRUSH UTILS
// ------------------------------------

fun getAvatarBrush(index: Int): Brush {
    return when (index) {
        1 -> Brush.sweepGradient(listOf(Color(0xFFE040FB), Color(0xFF00F5FF)))
        2 -> Brush.verticalGradient(listOf(Color(0xFFFFB300), Color(0xFFFF3D00)))
        3 -> Brush.horizontalGradient(listOf(Color(0xFF00E676), Color(0xFF00B0FF)))
        else -> Brush.radialGradient(listOf(Color(0xFFFF1744), Color(0xFFD500F9)))
    }
}

fun getAvatarEmoji(index: Int): String {
    return when (index) {
        1 -> "⚡"
        2 -> "🦊"
        3 -> "👾"
        else -> "🦁"
    }
}
