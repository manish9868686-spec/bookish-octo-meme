package com.example

import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onRoot
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.GameOutcomeOverlay
import com.github.takahirom.roborazzi.RobolectricDeviceQualifiers
import com.github.takahirom.roborazzi.captureRoboImage
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode

@RunWith(RobolectricTestRunner::class)
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@Config(qualifiers = RobolectricDeviceQualifiers.Pixel8, sdk = [36])
class GreetingScreenshotTest {

  @get:Rule val composeTestRule = createComposeRule()

  @Test
  fun outcome_overlay_screenshot() {
    composeTestRule.setContent { 
      MyApplicationTheme { 
        GameOutcomeOverlay(
          isSuccess = true,
          titleText = "🏆 TEST VICTORY 🏆",
          subtitleText = "Congratulations! You completed the game successfully.",
          score = 1250,
          rewardText = "🪙 +350 Coins",
          buttonText = "CLAIM REWARD",
          onConfirm = {}
        )
      } 
    }

    composeTestRule.onRoot().captureRoboImage(filePath = "src/test/screenshots/victory_outcome.png")
  }
}
